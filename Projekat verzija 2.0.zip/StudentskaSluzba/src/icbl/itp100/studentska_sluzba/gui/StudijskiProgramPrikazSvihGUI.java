package icbl.itp100.studentska_sluzba.gui;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.StudijskiProgramDAO;
import icbl.itp100.studentska_sluzba.dto.StudijskiProgramDTO;
import icbl.itp100.studentska_sluzba.table_model.StudijskiProgramTableModel;

public class StudijskiProgramPrikazSvihGUI extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudijskiProgramPrikazSvihGUI frame = new StudijskiProgramPrikazSvihGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudijskiProgramPrikazSvihGUI() {
		setType(Type.POPUP);
		setTitle("Prikaz svih studijskih programa iz baze");
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		Vector<StudijskiProgramDTO> programi = StudijskiProgramDAO.getAll();
		List<StudijskiProgramDTO> programiKaoLista = new ArrayList<>(programi);

		StudijskiProgramTableModel sptm = new StudijskiProgramTableModel(programiKaoLista);

		table = new JTable(sptm);
		table.setBounds(10, 11, 414, 240);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 434, 261);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);

	}

}
