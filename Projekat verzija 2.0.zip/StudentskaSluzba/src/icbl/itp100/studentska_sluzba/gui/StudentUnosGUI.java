package icbl.itp100.studentska_sluzba.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import icbl.itp100.studentska_sluzba.dao.StudentDAO;
import icbl.itp100.studentska_sluzba.dto.StudentDTO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StudentUnosGUI extends JFrame {

	private JPanel contentPane;
	private JTextField tfIme;
	private JTextField tfPrezime;
	private JTextField tfBrojIndeksa;
	private JTextField tfGodinaUpisa;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentUnosGUI frame = new StudentUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudentUnosGUI() {
		setTitle("Student | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIme = new JLabel("Ime:");
		lblIme.setBounds(10, 11, 171, 14);
		contentPane.add(lblIme);
		
		tfIme = new JTextField();
		tfIme.setBounds(10, 36, 263, 20);
		contentPane.add(tfIme);
		tfIme.setColumns(10);
		
		JLabel lblPrezime = new JLabel("Prezime:");
		lblPrezime.setBounds(10, 67, 171, 14);
		contentPane.add(lblPrezime);
		
		tfPrezime = new JTextField();
		tfPrezime.setBounds(10, 92, 263, 20);
		contentPane.add(tfPrezime);
		tfPrezime.setColumns(10);
		
		JLabel lblBrojIndeksa = new JLabel("Broj indeksa:");
		lblBrojIndeksa.setBounds(10, 123, 171, 14);
		contentPane.add(lblBrojIndeksa);
		
		tfBrojIndeksa = new JTextField();
		tfBrojIndeksa.setBounds(10, 148, 263, 20);
		contentPane.add(tfBrojIndeksa);
		tfBrojIndeksa.setColumns(10);
		
		JLabel lblGodinaUpisa = new JLabel("Godina upisa:");
		lblGodinaUpisa.setBounds(10, 179, 171, 14);
		contentPane.add(lblGodinaUpisa);
		
		tfGodinaUpisa = new JTextField();
		tfGodinaUpisa.setBounds(10, 204, 263, 20);
		contentPane.add(tfGodinaUpisa);
		tfGodinaUpisa.setColumns(10);
		
		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String imeStudenta = tfIme.getText();
				String prezimeStudenta = tfPrezime.getText();
				int indeksStudenta = Integer.parseInt(tfBrojIndeksa.getText());
				int upisStudenta = Integer.parseInt(tfGodinaUpisa.getText());
				
				StudentDTO s = new StudentDTO();
				s.setImeStudenta(imeStudenta);
				s.setPrezimeStudenta(prezimeStudenta);
				s.setBrojIndeksa(indeksStudenta);
				s.setGodinaUpisa(upisStudenta);
				boolean uspjesno = StudentDAO.dodajStudent(s);
				String bool = uspjesno ? "Uspjesno ste dodali studenta." : "Dogodila se greska pri dodavanju studenta.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		btnUnesi.setBounds(333, 228, 91, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazSvihStudenata = new JButton("Prikaz svih studenata");
		btnPrikazSvihStudenata.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentPrikazSvihGUI prikazSvih=new StudentPrikazSvihGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazSvihStudenata.setBounds(10, 228, 186, 23);
		contentPane.add(btnPrikazSvihStudenata);
		
	}
	
}
