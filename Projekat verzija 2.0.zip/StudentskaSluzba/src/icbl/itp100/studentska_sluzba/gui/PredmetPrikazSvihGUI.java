package icbl.itp100.studentska_sluzba.gui;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.PredmetDAO;
import icbl.itp100.studentska_sluzba.dto.PredmetDTO;
import icbl.itp100.studentska_sluzba.table_model.PredmetTableModel;

public class PredmetPrikazSvihGUI extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PredmetPrikazSvihGUI frame = new PredmetPrikazSvihGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PredmetPrikazSvihGUI() {
		setType(Type.POPUP);
		setTitle("Prikaz svih predmeta iz baze");
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		Vector<PredmetDTO> predmeti = PredmetDAO.getAll();
		List<PredmetDTO> predmetiKaoLista = new ArrayList<>(predmeti);

		PredmetTableModel ptm = new PredmetTableModel(predmetiKaoLista);

		table = new JTable(ptm);
		table.setBounds(10, 11, 414, 240);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 434, 261);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);

	}

}
