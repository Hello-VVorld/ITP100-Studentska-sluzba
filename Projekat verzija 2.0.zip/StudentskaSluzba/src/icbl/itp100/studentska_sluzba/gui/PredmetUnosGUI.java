package icbl.itp100.studentska_sluzba.gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.PredmetDAO;
import icbl.itp100.studentska_sluzba.dto.PredmetDTO;

public class PredmetUnosGUI extends JFrame {

	private JPanel contentPane;
	private JTextField tfNaziv;
	private JTextField tfEcts;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PredmetUnosGUI frame = new PredmetUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PredmetUnosGUI() {
		setTitle("Predmet | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNaziv = new JLabel("Naziv:");
		lblNaziv.setBounds(10, 11, 101, 14);
		contentPane.add(lblNaziv);

		tfNaziv = new JTextField();
		tfNaziv.setBounds(10, 36, 257, 20);
		contentPane.add(tfNaziv);
		tfNaziv.setColumns(10);

		JLabel lblObavezan = new JLabel("Obavezan / Izborni:");
		lblObavezan.setBounds(10, 67, 157, 14);
		contentPane.add(lblObavezan);

		JComboBox cbObavezan = new JComboBox();
		cbObavezan.setModel(new DefaultComboBoxModel(new Integer[] { 1, 0 }));
		cbObavezan.setBounds(10, 92, 157, 22);
		contentPane.add(cbObavezan);

		JLabel lblEcts = new JLabel("ECTS:");
		lblEcts.setBounds(10, 125, 101, 14);
		contentPane.add(lblEcts);

		tfEcts = new JTextField();
		tfEcts.setBounds(10, 150, 157, 20);
		contentPane.add(tfEcts);
		tfEcts.setColumns(10);

		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String nazivPredmeta = tfNaziv.getText();
				int ects = Integer.parseInt(tfEcts.getText());
				boolean status = cbObavezan.equals(1) ? true : false;
				PredmetDTO pr = new PredmetDTO();
				pr.setNazivPredmeta(nazivPredmeta);
				pr.setObavezan(status);
				pr.setEcts(ects);
				boolean uspjesno = PredmetDAO.dodajPredmet(pr);
				String bool = uspjesno ? "Uspjesno ste dodali predmet." : "Dogodila se greska pri dodavanju predmeta.";
				JOptionPane.showMessageDialog(null, bool);

			}
		});
		btnUnesi.setBounds(335, 228, 89, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazSvihPredmeta = new JButton("Prikaz svih predmeta");
		btnPrikazSvihPredmeta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PredmetPrikazSvihGUI prikazSvih=new PredmetPrikazSvihGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazSvihPredmeta.setBounds(10, 228, 186, 23);
		contentPane.add(btnPrikazSvihPredmeta);

	}

}
