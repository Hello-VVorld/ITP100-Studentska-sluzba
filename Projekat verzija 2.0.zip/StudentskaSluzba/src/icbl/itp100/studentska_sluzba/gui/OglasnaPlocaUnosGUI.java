package icbl.itp100.studentska_sluzba.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import icbl.itp100.studentska_sluzba.dao.OglasnaPlocaDAO;
import icbl.itp100.studentska_sluzba.dto.OglasnaPlocaDTO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class OglasnaPlocaUnosGUI extends JFrame {

	private JPanel contentPane;
	private JTextArea taObavjestenje;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OglasnaPlocaUnosGUI frame = new OglasnaPlocaUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public OglasnaPlocaUnosGUI() {
		setTitle("OglasnaPloca | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JTextArea taObavjestenje = new JTextArea();
		taObavjestenje.setBounds(10, 37, 310, 165);
		contentPane.add(taObavjestenje);

		JLabel lblObavjestenje = new JLabel("Obavjestenje:");
		lblObavjestenje.setBounds(10, 11, 162, 14);
		contentPane.add(lblObavjestenje);

		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String oglas = taObavjestenje.getText();
				OglasnaPlocaDTO o = new OglasnaPlocaDTO();
				o.setVrstaOglasa(oglas);
				boolean uspjesno = OglasnaPlocaDAO.dodajOglasnaPloca(o);
				String bool = uspjesno ? "Uspjesno ste dodali na oglasnu plocu."
						: "Dogodila se greska pri dodavanju na oglasnu plocu.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		btnUnesi.setBounds(333, 228, 91, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazOglasnePloce = new JButton("Prikaz oglasne ploce");
		btnPrikazOglasnePloce.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OglasnaPlocaPrikazSvihGUI prikazSvih=new OglasnaPlocaPrikazSvihGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazOglasnePloce.setBounds(10, 228, 186, 23);
		contentPane.add(btnPrikazOglasnePloce);

	}
	
}
