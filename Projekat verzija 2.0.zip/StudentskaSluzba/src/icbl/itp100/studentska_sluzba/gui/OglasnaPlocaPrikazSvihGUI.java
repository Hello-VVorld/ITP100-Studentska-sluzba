package icbl.itp100.studentska_sluzba.gui;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.OglasnaPlocaDAO;
import icbl.itp100.studentska_sluzba.dto.OglasnaPlocaDTO;
import icbl.itp100.studentska_sluzba.table_model.OglasnaPlocaTableModel;

public class OglasnaPlocaPrikazSvihGUI extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OglasnaPlocaPrikazSvihGUI frame = new OglasnaPlocaPrikazSvihGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public OglasnaPlocaPrikazSvihGUI() {
		setType(Type.POPUP);
		setTitle("Prikaz svih vrsta oglasa iz baze");
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		Vector<OglasnaPlocaDTO> ploca = OglasnaPlocaDAO.getAll();
		List<OglasnaPlocaDTO> plocaKaoLista = new ArrayList<>(ploca);

		OglasnaPlocaTableModel optm = new OglasnaPlocaTableModel(plocaKaoLista);

		table = new JTable(optm);
		table.setBounds(10, 11, 414, 240);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 434, 261);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);

	}

}
