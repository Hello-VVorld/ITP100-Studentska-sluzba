package icbl.itp100.studentska_sluzba.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import icbl.itp100.studentska_sluzba.dao.OglasDAO;
import icbl.itp100.studentska_sluzba.dto.OglasDTO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Vector;
import java.awt.event.ActionEvent;

public class OglasUnosGUI extends JFrame {

	private JPanel contentPane;
	private JTextField tfNaziv;
	private JTextArea taSadrzaj;
	private JComboBox cbVrstaOglasa;
	private JButton btnUnesi;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OglasUnosGUI frame = new OglasUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public OglasUnosGUI() {
		setTitle("Oglas | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNaziv = new JLabel("Naziv:");
		lblNaziv.setBounds(10, 11, 157, 14);
		contentPane.add(lblNaziv);

		tfNaziv = new JTextField();
		tfNaziv.setBounds(10, 36, 273, 20);
		contentPane.add(tfNaziv);
		tfNaziv.setColumns(10);

		JLabel lblSadrzaj = new JLabel("Sadrzaj:");
		lblSadrzaj.setBounds(10, 67, 157, 14);
		contentPane.add(lblSadrzaj);

		JTextArea taSadrzaj = new JTextArea();
		taSadrzaj.setBounds(10, 95, 273, 59);
		contentPane.add(taSadrzaj);

		JLabel lblVrstaOglasa = new JLabel("Vrsta oglasa:");
		lblVrstaOglasa.setBounds(10, 165, 157, 14);
		contentPane.add(lblVrstaOglasa);

		Vector<OglasDTO> sviOglasi = OglasDAO.getAll();

		JComboBox cbVrstaOglasa = new JComboBox(sviOglasi);
		cbVrstaOglasa.setBounds(10, 190, 157, 22);
		contentPane.add(cbVrstaOglasa);

		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String nazivOglasa = tfNaziv.getText();
				String sadrzaj = taSadrzaj.getText();
				String oglas = cbVrstaOglasa.getSelectedItem().toString();
				String parsiranOglas[] = oglas.split("-");
				int idOglas = Integer.parseInt(parsiranOglas[0]);
				OglasDTO od = new OglasDTO();
				od.setNazivOglasa(nazivOglasa);
				od.setSadrzaj(sadrzaj);
				od.setOglasID(idOglas);
				boolean uspjesno = OglasDAO.dodajOglas(od);
				String bool = uspjesno ? "Uspjesno ste dodali oglas!" : "Dogodila se greska pri dodavanju oglasa!";
				JOptionPane.showMessageDialog(null, bool);

			}
		});
		btnUnesi.setBounds(335, 228, 89, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazSvihOglasa = new JButton("Prikaz svih oglasa");
		btnPrikazSvihOglasa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OglasPrikazSvihGUI prikazSvih=new OglasPrikazSvihGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazSvihOglasa.setBounds(10, 228, 186, 23);
		contentPane.add(btnPrikazSvihOglasa);
		
	}
	
}
