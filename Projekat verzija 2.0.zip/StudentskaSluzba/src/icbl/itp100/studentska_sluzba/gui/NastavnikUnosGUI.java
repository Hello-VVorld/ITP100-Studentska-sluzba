package icbl.itp100.studentska_sluzba.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.NastavnikDAO;
import icbl.itp100.studentska_sluzba.dto.NastavnikDTO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NastavnikUnosGUI extends JFrame {

	private JPanel contentPane;
	private JTextField tfIme;
	private JTextField tfPrezime;
	private JTextField tfZvanje;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NastavnikUnosGUI frame = new NastavnikUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NastavnikUnosGUI() {
		setTitle("Nastavnik | Upis");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIme = new JLabel("Ime:");
		lblIme.setBounds(10, 11, 149, 14);
		contentPane.add(lblIme);
		
		tfIme = new JTextField();
		tfIme.setBounds(10, 36, 235, 20);
		contentPane.add(tfIme);
		tfIme.setColumns(10);
		
		JLabel lblPrezime = new JLabel("Prezime:");
		lblPrezime.setBounds(10, 67, 149, 14);
		contentPane.add(lblPrezime);
		
		tfPrezime = new JTextField();
		tfPrezime.setBounds(10, 92, 235, 20);
		contentPane.add(tfPrezime);
		tfPrezime.setColumns(10);
		
		JLabel lblZvanje = new JLabel("Zvanje:");
		lblZvanje.setBounds(10, 123, 149, 14);
		contentPane.add(lblZvanje);
		
		tfZvanje = new JTextField();
		tfZvanje.setBounds(10, 148, 235, 20);
		contentPane.add(tfZvanje);
		tfZvanje.setColumns(10);
		
		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String imeNastavnika = tfIme.getText();
				String prezimeNastavnika = tfPrezime.getText();
				String zvanjeNastavnika = tfZvanje.getText();
				
				NastavnikDTO n = new NastavnikDTO();
				n.setImeNastavnika(imeNastavnika);
				n.setPrezimeNastavnika(prezimeNastavnika);
				n.setZvanje(zvanjeNastavnika);
				boolean uspjesno = NastavnikDAO.dodajNastavnik(n);
				String bool = uspjesno ? "Uspjesno ste dodali nastavnika." : "Dogodila se greska pri dodavanju nastavnika.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		btnUnesi.setBounds(333, 228, 91, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazSvihNastavnika = new JButton("Prikaz svih nastavnika");
		btnPrikazSvihNastavnika.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NastavnikPrikazSvihGUI prikazSvih=new NastavnikPrikazSvihGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazSvihNastavnika.setBounds(10, 228, 186, 23);
		contentPane.add(btnPrikazSvihNastavnika);
		
	}

}
