package icbl.itp100.studentska_sluzba.dto;

public class StudijskiProgramDTO {

	int studijskiProgramID;
	String nazivSP;
	int ciklusFK;
	
	public StudijskiProgramDTO(int studijskiProgramID, String nazivSP, int ciklusFK) {
		super();
		this.studijskiProgramID = studijskiProgramID;
		this.nazivSP = nazivSP;
		this.ciklusFK = ciklusFK;
	}
	
	public StudijskiProgramDTO() {
		super();
	}
	
	public int getStudijskiProgramID() {
		return studijskiProgramID;
	}
	
	public void setStudijskiProgramID(int studijskiProgramID) {
		this.studijskiProgramID = studijskiProgramID;
	}
	
	public String getNazivSP() {
		return nazivSP;
	}
	
	public void setNazivSP(String nazivSP) {
		this.nazivSP = nazivSP;
	}
	
	public int getCiklusFK() {
		return ciklusFK;
	}
	
	public void setCiklusFK(int ciklusFK) {
		this.ciklusFK = ciklusFK;
	}
	
	@Override
	public String toString() {
		return studijskiProgramID + " - " + nazivSP;
	}
	
}
