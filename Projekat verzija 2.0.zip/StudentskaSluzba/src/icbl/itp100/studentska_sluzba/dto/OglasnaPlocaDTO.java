package icbl.itp100.studentska_sluzba.dto;

public class OglasnaPlocaDTO {

	int oglasnaPlocaID;
	String vrstaOglasa;

	public OglasnaPlocaDTO(int oglasnaPlocaID, String vrstaOglasa) {
		super();
		this.oglasnaPlocaID = oglasnaPlocaID;
		this.vrstaOglasa = vrstaOglasa;
	}

	public OglasnaPlocaDTO() {
		super();
	}

	public int getOglasnaPlocaID() {
		return oglasnaPlocaID;
	}

	public void setOglasnaPlocaID(int oglasnaPlocaID) {
		this.oglasnaPlocaID = oglasnaPlocaID;
	}

	public String getVrstaOglasa() {
		return vrstaOglasa;
	}

	public void setVrstaOglasa(String vrstaOglasa) {
		this.vrstaOglasa = vrstaOglasa;
	}

	@Override
	public String toString() {
		return oglasnaPlocaID + " - " + vrstaOglasa;
	}

}
