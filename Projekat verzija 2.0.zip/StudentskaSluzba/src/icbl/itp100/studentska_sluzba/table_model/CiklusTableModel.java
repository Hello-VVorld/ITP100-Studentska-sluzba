package icbl.itp100.studentska_sluzba.table_model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import icbl.itp100.studentska_sluzba.dto.CiklusDTO;

public class CiklusTableModel extends AbstractTableModel {

	// definisemo listu ciklusa
	private List<CiklusDTO> ciklusi;

	public CiklusTableModel(List<CiklusDTO> ciklus) {
		this.ciklusi = ciklus;
	}

	@Override
	public int getRowCount() {
		return ciklusi.size();
	}

	@Override
	public int getColumnCount() {
		return 2; // imamo dvije kolone u tabeli Ciklus: ID i naziv
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		CiklusDTO ciklus = ciklusi.get(rowIndex);
		Object value = null;

		switch (columnIndex) {
		case 0:
			value = ciklus.getCiklusID();
			break;
		case 1:
			value = ciklus.getNazivCiklusa();
			break;
			
		}
		return value;
	}

	// za zaglavlje tabele
	@Override
	public String getColumnName(int column) {
		String name = "??";
		switch (column) {
		case 0:
			name = "ID";
			break;
		case 1:
			name = "Naziv";
			break;
		}
		return name;
	}

}
