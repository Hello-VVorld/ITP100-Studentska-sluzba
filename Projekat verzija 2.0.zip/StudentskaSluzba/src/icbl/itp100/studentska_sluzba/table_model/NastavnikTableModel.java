package icbl.itp100.studentska_sluzba.table_model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import icbl.itp100.studentska_sluzba.dto.NastavnikDTO;

public class NastavnikTableModel extends AbstractTableModel {
	private List<NastavnikDTO> nastavnici;

	public NastavnikTableModel(List<NastavnikDTO> nastavnici) {
		this.nastavnici = nastavnici;
	}

	@Override
	public int getRowCount() {
		return nastavnici.size();
	}

	@Override
	public int getColumnCount() {
		return 4;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		NastavnikDTO nastavnik = nastavnici.get(rowIndex);
		Object value = null;

		switch (columnIndex) {
		case 0:
			value = nastavnik.getNastavnikID();
			break;
		case 1:
			value = nastavnik.getImeNastavnika();
			break;
		case 2:
			value = nastavnik.getPrezimeNastavnika();
			break;
		case 3:
			value = nastavnik.getZvanje();
			break;

		}
		return value;
	}

	@Override
	public String getColumnName(int column) {
		String name = "??";
		switch (column) {
		case 0:
			name = "ID";
			break;
		case 1:
			name = "Ime";
			break;
		case 2:
			name = "Prezime";
			break;
		case 3:
			name = "Zvanje";
			break;
		}
		return name;
	}

}
