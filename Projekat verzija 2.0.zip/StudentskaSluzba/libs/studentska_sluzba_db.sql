SELECT predmet.naziv, student.ime, student.prezime, FROM ispit
INNER JOIN student ON ispit.student_fk = student.id
INNER JOIN predmet ON ispit.predmet_fk = predmet.id
WHERE ocjena > 5;