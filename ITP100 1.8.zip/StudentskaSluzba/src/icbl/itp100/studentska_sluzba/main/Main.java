package icbl.itp100.studentska_sluzba.main;

import java.sql.SQLException;
import java.util.Scanner;
import java.util.Vector;

import icbl.itp100.studentska_sluzba.dao.CiklusDAO;
import icbl.itp100.studentska_sluzba.dao.StudijskiProgramDAO;
import icbl.itp100.studentska_sluzba.dto.CiklusDTO;
import icbl.itp100.studentska_sluzba.dto.StudijskiProgramDTO;

public class Main {

	public static void main(String[] args) throws SQLException {
		
		// Prikaz svih ciklusa
		Vector<CiklusDTO> ciklus = CiklusDAO.getAll();
		System.out.println("U bazi je " + ciklus.size() + " ciklusa.");
		System.out.println("Spisak ciklusa: ");
		for (CiklusDTO c : ciklus) {
			System.out.println(c.getNazivCiklusa());
		}

		Vector<StudijskiProgramDTO> sp = StudijskiProgramDAO.getAll();
		System.out.println("U bazi je " + sp.size() + " studijska programa.");
		System.out.println("Spisak studijskih programa: ");
		for (StudijskiProgramDTO s : sp) {
			System.out.println(s.getNazivSP() + " sa ciklusa " + s.getCiklusFK());
		}

		// Dodavanje novog ciklusa
		Scanner sc = new Scanner(System.in);
		CiklusDTO c = new CiklusDTO();
		System.out.println("*** DODAVANJE NOVOG CIKLUSA ***");
		System.out.println("Unesite naziv: ");
		c.setNazivCiklusa(sc.nextLine());
		boolean uspjesno = CiklusDAO.dodajCiklus(c);
		if (uspjesno) {
			System.out.println("Uspjesno ste dodali ciklus.");
		} else {
			System.out.println("Dogodila se greska pri dodavanju ciklusa.");
		}

		/*
		 * System.out.println("**********AZURIRAJ FILM***********");
		 * System.out.println("Unesite ID filma: "); String idFilma=sc.nextLine();
		 * System.out.println("Unesite novi naziv filma:"); String
		 * nazivFilma=sc.nextLine(); uspjesno=StudentskaSluzbaDAO.azurirajFilm(idFilma,
		 * nazivFilma); if(uspjesno) System.out.println("Uspjesno ste azurirali film.");
		 * else System.out.println("Azuriranje nije uspjelo.");
		 * 
		 * System.out.println("************BRISANJE FILMA***********");
		 * System.out.println("Unesite ID filma:"); idFilma=sc.nextLine();
		 * uspjesno=StudentskaSluzbaDAO.obrisiFilm(idFilma); if(uspjesno)
		 * System.out.println("Uspjesno ste obrisali film."); else
		 * System.out.println("Brisanje nije uspjelo."); sc.close(); }
		 */
	}
	
}
