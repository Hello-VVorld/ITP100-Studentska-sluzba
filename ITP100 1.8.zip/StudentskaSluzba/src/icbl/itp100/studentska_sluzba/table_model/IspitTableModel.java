package icbl.itp100.studentska_sluzba.table_model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import icbl.itp100.studentska_sluzba.dto.IspitDTO;

public class IspitTableModel extends AbstractTableModel {
	private List<IspitDTO> ispiti;

	public IspitTableModel(List<IspitDTO> ispiti) {
		this.ispiti = ispiti;
	}

	@Override
	public int getRowCount() {
		return ispiti.size();
	}

	@Override
	public int getColumnCount() {
		return 8;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		IspitDTO ispit = ispiti.get(rowIndex);
		Object value = null;

		switch (columnIndex) {
		case 0:
			value = ispit.getIspitID();
			break;
		case 1:
			value = ispit.getDatumIspita();
			break;
		case 2:
			value = ispit.getOcjena();
			break;
		case 3:
			value = ispit.getBrojBodova();
			break;
		case 4:
			value = ispit.getStudentFK();
			break;
		case 5:
			value = ispit.getPredmetFK();
			break;
		case 6:
			value = ispit.getNastavnikFK();
			break;
		case 7:
			value = ispit.getStudijskiProgramFK();
			break;
		}

		return value;
	}

	@Override
	public String getColumnName(int column) {
		String name = "??";
		switch (column) {
		case 0:
			name = "ID";
			break;
		case 1:
			name = "Datum";
			break;
		case 2:
			name = "Ocjena";
			break;
		case 3:
			name = "Broj bodova";
			break;
		case 4:
			name = "Student";
			break;
		case 5:
			name = "Predmet";
			break;
		case 6:
			name = "Nastavnik";
			break;
		case 7:
			name = "Studijski program";
			break;
		}
		return name;
	}

}
