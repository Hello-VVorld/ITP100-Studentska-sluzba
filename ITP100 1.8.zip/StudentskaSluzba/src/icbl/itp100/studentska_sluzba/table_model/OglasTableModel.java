package icbl.itp100.studentska_sluzba.table_model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import icbl.itp100.studentska_sluzba.dto.OglasDTO;

public class OglasTableModel extends AbstractTableModel {
	private List<OglasDTO> oglasi;

	public OglasTableModel(List<OglasDTO> oglasi) {
		this.oglasi = oglasi;
	}

	@Override
	public int getRowCount() {
		return oglasi.size();
	}

	@Override
	public int getColumnCount() {
		return 6;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		OglasDTO oglas = oglasi.get(rowIndex);
		Object value = null;

		switch (columnIndex) {
		case 0:
			value = oglas.getOglasID();
			break;
		case 1:
			value = oglas.getNazivOglasa();
			break;
		case 2:
			value = oglas.getSadrzaj();
			break;
		case 3:
			value = oglas.getDatum();
			break;
		case 4:
			value = oglas.isAktivan();
			break;
		case 5:
			value = oglas.getOglasnaPlocaFK();
			break;
		}
		
		return value;
	}

	@Override
	public String getColumnName(int column) {
		String name = "??";
		switch (column) {
		case 0:
			name = "ID";
			break;
		case 1:
			name = "Naziv";
			break;
		case 2:
			name = "Sadrzaj";
			break;
		case 3:
			name = "Datum";
			break;
		case 4:
			name = "Aktivan";
			break;
		case 5:
			name = "Oglasna ploca";
			break;
		}
		return name;
	}
	
}
