package icbl.itp100.studentska_sluzba.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import icbl.itp100.studentska_sluzba.dto.NastavnikDTO;

public class NastavnikDAO {
	
	public static Vector<NastavnikDTO> getAll() {
		Vector<NastavnikDTO> retVal = new Vector<NastavnikDTO>();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM nastavnik";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();

			while (rs.next())
				retVal.add(new NastavnikDTO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
	}

	public static boolean dodajNastavnik(NastavnikDTO n) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "INSERT INTO nastavnik (ime, prezime, zvanje) VALUES (?, ?, ?)";
		
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setString(1, n.getImeNastavnika());
			ps.setString(2, n.getPrezimeNastavnika());
			ps.setString(3, n.getZvanje());

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static boolean azurirajNastavnik(int nastavnikID, String imeNastavnika, String prezimeNastavnika, String zvanje) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "UPDATE nastavnik SET ime = ?, prezime = ?, zvanje = ? WHERE id = ?";
		
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setString(1, imeNastavnika);
			ps.setString(2, prezimeNastavnika);
			ps.setString(3, zvanje);
			ps.setInt(4, nastavnikID);

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static boolean obrisiNastavnik(int nastavnikID) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "DELETE FROM ciklus WHERE id = ?";
		
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, nastavnikID);

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static NastavnikDTO getByID(int nastavnik) {
		NastavnikDTO retVal = new NastavnikDTO();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM nastavnik WHERE id = ?";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, nastavnik);
			rs = ps.executeQuery();

			while (rs.next()) {
				retVal.setNastavnikID(rs.getInt(1));
				retVal.setImeNastavnika(rs.getString(2));
				retVal.setPrezimeNastavnika(rs.getString(3));
				retVal.setZvanje(rs.getString(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
	}
	
	public static void main(String[] args) {
		System.out.println(NastavnikDAO.getAll());
	}

	public static NastavnikDTO getByID(int i, NastavnikDTO byID) {
		// TODO Auto-generated method stub
		return null;
	}

}
