package icbl.itp100.studentska_sluzba.dto;

public class PredmetDTO {

	int predmetID;
	String nazivPredmeta;
	boolean obavezan;
	int ects;

	public PredmetDTO(int predmetID, String nazivPredmeta, boolean obavezan, int ects) {
		super();
		this.predmetID = predmetID;
		this.nazivPredmeta = nazivPredmeta;
		this.obavezan = obavezan;
		this.ects = ects;
	}

	public PredmetDTO() {
		super();
	}

	public int getPredmetID() {
		return predmetID;
	}

	public void setPredmetID(int predmetID) {
		this.predmetID = predmetID;
	}

	public String getNazivPredmeta() {
		return nazivPredmeta;
	}

	public void setNazivPredmeta(String nazivPredmeta) {
		this.nazivPredmeta = nazivPredmeta;
	}

	public boolean isObavezan() {
		return obavezan;
	}

	public void setObavezan(boolean obavezan) {
		this.obavezan = obavezan;
	}

	public int getEcts() {
		return ects;
	}

	public void setEcts(int ects) {
		this.ects = ects;
	}

	@Override
	public String toString() {
		return predmetID + " - " + nazivPredmeta;
	}
	
}
