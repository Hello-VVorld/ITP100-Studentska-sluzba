package icbl.itp100.studentska_sluzba.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.CiklusDAO;
import icbl.itp100.studentska_sluzba.dao.PredmetDAO;
import icbl.itp100.studentska_sluzba.dto.CiklusDTO;
import icbl.itp100.studentska_sluzba.dto.PredmetDTO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PredmetUnosGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PredmetUnosGUI frame = new PredmetUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PredmetUnosGUI() {
		setTitle("Predmet | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNaziv = new JLabel("Naziv:");
		lblNaziv.setBounds(10, 11, 101, 14);
		contentPane.add(lblNaziv);
		
		textField = new JTextField();
		textField.setBounds(10, 36, 257, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblObavezan = new JLabel("Obavezan:");
		lblObavezan.setBounds(10, 67, 101, 14);
		contentPane.add(lblObavezan);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new Integer[] {1}));
		comboBox.setBounds(10, 92, 85, 22);
		contentPane.add(comboBox);
		
		JLabel lblEcts = new JLabel("Ects:");
		lblEcts.setBounds(10, 125, 101, 14);
		contentPane.add(lblEcts);
		
		textField_1 = new JTextField();
		textField_1.setBounds(15, 151, 96, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnUnos = new JButton("UNOS");
		btnUnos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nazivPredmeta = textField.getText();
				int ectsPredmeta = Integer.parseInt(textField_1.getText());
				//int statusPredmeta = Integer.parseInt(comboBox.getText());
				//String statusPredmeta = Integer.parseInt(o.get('uses_votes')).equals("1") ? true : false;
				boolean status = comboBox.equals(1) ? false : true;
				
				PredmetDTO pr = new PredmetDTO();
				pr.setNazivPredmeta(nazivPredmeta);
				pr.setObavezan(status);
				pr.setEcts(ectsPredmeta);
				
				boolean uspjesno = PredmetDAO.dodajPredmet(pr);
				String bool = uspjesno ? "Uspjesno ste dodali ciklus." : "Dogodila se greska pri dodavanju ciklusa.";
				JOptionPane.showMessageDialog(null, bool);
				
			}
		});
		btnUnos.setBounds(335, 228, 89, 23);
		contentPane.add(btnUnos);
		

	}
}
