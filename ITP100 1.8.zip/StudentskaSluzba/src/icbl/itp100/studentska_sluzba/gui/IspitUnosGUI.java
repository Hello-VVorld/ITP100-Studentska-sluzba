package icbl.itp100.studentska_sluzba.gui;

import java.awt.EventQueue;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.IspitDAO;
import icbl.itp100.studentska_sluzba.dao.NastavnikDAO;
import icbl.itp100.studentska_sluzba.dao.PredmetDAO;
import icbl.itp100.studentska_sluzba.dao.StudentDAO;
import icbl.itp100.studentska_sluzba.dao.StudijskiProgramDAO;
import icbl.itp100.studentska_sluzba.dto.IspitDTO;
import icbl.itp100.studentska_sluzba.dto.NastavnikDTO;
import icbl.itp100.studentska_sluzba.dto.PredmetDTO;
import icbl.itp100.studentska_sluzba.dto.StudentDTO;
import icbl.itp100.studentska_sluzba.dto.StudijskiProgramDTO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class IspitUnosGUI extends JFrame {

	private JPanel contentPane;
	private JTextField tfOcjena;
	private JTextField tfBodovi;
	private JTextField tfDatum;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IspitUnosGUI frame = new IspitUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IspitUnosGUI() {
		setTitle("Ispit | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblStudent = new JLabel("Student:");
		lblStudent.setBounds(33, 28, 126, 14);
		contentPane.add(lblStudent);

		// popuniti combo-box svim studentima
		Vector<StudentDTO> sviStudenti = StudentDAO.getAll();
		// dodamo ovaj vektor u combo-box kroz konstruktor
		JComboBox cbStudent = new JComboBox(sviStudenti);
		cbStudent.setBounds(156, 24, 301, 22);
		contentPane.add(cbStudent);

		JLabel lblPredmet = new JLabel("Predmet:");
		lblPredmet.setBounds(33, 77, 126, 14);
		contentPane.add(lblPredmet);

		Vector<PredmetDTO> sviPredmeti = PredmetDAO.getAll();
		JComboBox cbPredmet = new JComboBox(sviPredmeti);
		cbPredmet.setBounds(156, 73, 301, 22);
		contentPane.add(cbPredmet);

		JLabel lblStudijskiProgram = new JLabel("Studijski program:");
		lblStudijskiProgram.setBounds(33, 126, 126, 14);
		contentPane.add(lblStudijskiProgram);

		Vector<StudijskiProgramDTO> sviSP = StudijskiProgramDAO.getAll();
		JComboBox cbStudijskiProgram = new JComboBox(sviSP);
		cbStudijskiProgram.setBounds(156, 122, 301, 22);
		contentPane.add(cbStudijskiProgram);

		JLabel lblNastavnik = new JLabel("Nastavnik:");
		lblNastavnik.setBounds(33, 174, 126, 14);
		contentPane.add(lblNastavnik);

		Vector<NastavnikDTO> sviNastavnici = NastavnikDAO.getAll();
		JComboBox cbNastavnik = new JComboBox(sviNastavnici);
		cbNastavnik.setBounds(156, 170, 301, 22);
		contentPane.add(cbNastavnik);

		JLabel lblOcjena = new JLabel("Ocjena:");
		lblOcjena.setBounds(33, 224, 126, 14);
		contentPane.add(lblOcjena);

		tfOcjena = new JTextField();
		tfOcjena.setBounds(156, 221, 301, 20);
		contentPane.add(tfOcjena);
		tfOcjena.setColumns(10);

		JLabel lblBodovi = new JLabel("Bodovi:");
		lblBodovi.setBounds(33, 273, 126, 14);
		contentPane.add(lblBodovi);

		tfBodovi = new JTextField();
		tfBodovi.setBounds(156, 270, 301, 20);
		contentPane.add(tfBodovi);
		tfBodovi.setColumns(10);

		JLabel lblDatum = new JLabel("Datum:");
		lblDatum.setBounds(33, 319, 126, 14);
		contentPane.add(lblDatum);

		tfDatum = new JTextField();
		tfDatum.setBounds(156, 316, 301, 20);
		contentPane.add(tfDatum);
		tfDatum.setColumns(10);

		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int studentFK = Integer.parseInt(cbStudent.getSelectedItem().toString().split(" - ")[0]);

				int predmetFK = Integer.parseInt(cbPredmet.getSelectedItem().toString().split(" - ")[0]);

				int studijskiProgramFK = Integer
						.parseInt(cbStudijskiProgram.getSelectedItem().toString().split(" - ")[0]);

				int nastavnikFK = Integer.parseInt(cbNastavnik.getSelectedItem().toString().split(" - ")[0]);

				int ocjena = Integer.parseInt(tfOcjena.getText());

				int bodovi = Integer.parseInt(tfBodovi.getText());

				String datum = tfDatum.getText();

				IspitDTO ispitZaUnos = new IspitDTO(0, datum, ocjena, bodovi, studentFK, predmetFK, nastavnikFK,
						studijskiProgramFK);

				boolean uspjesnoDodavanje = IspitDAO.dodajIspit(ispitZaUnos);
				if (uspjesnoDodavanje) {
					JOptionPane.showMessageDialog(null, "Unos ispita uspjesan!");
				} else
					JOptionPane.showMessageDialog(null, "Unos nije uspio!");

			}
		});
		btnUnesi.setBounds(385, 378, 89, 23);
		contentPane.add(btnUnesi);
	}

}
