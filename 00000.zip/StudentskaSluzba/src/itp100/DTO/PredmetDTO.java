package itp100.DTO;

public class PredmetDTO {
	
	int Id;
	String naziv;
	boolean obavezan;
	int ects;
	public PredmetDTO(int id, String naziv, boolean obavezan, int ects) {
		super();
		Id = id;
		this.naziv = naziv;
		this.obavezan = obavezan;
		this.ects = ects;
	}
	public PredmetDTO() {
		super();
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getNaziv() {
		return naziv;
	}
	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public Boolean getObavezan() {
		return obavezan;
	}
	public void setObavezan(boolean obavezan) {
		this.obavezan = obavezan;
	}
	public int getEcts() {
		return ects;
	}
	public void setEcts(int ects) {
		this.ects = ects;
	}
	@Override
	public String toString() {
		return "PredmetDTO [Id=" + Id + ", naziv=" + naziv + ", obavezan=" + obavezan + ", ects=" + ects + "]";
	}
	
	
	
	

}
