package itp100.DTO;

public class StudentiDTO {

	int Id;
	String imeStudenta;
	String prezimeStudenta;
	int brojIndeksa;
	int godinaStudija;
	public StudentiDTO(int id, String imeStudenta, String prezimeStudenta, int brojIndeksa, int godinaStudija) {
		super();
		Id = id;
		this.imeStudenta = imeStudenta;
		this.prezimeStudenta = prezimeStudenta;
		this.brojIndeksa = brojIndeksa;
		this.godinaStudija = godinaStudija;
	}
	public StudentiDTO() {
		super();
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getImeStudenta() {
		return imeStudenta;
	}
	public void setImeStudenta(String imeStudenta) {
		this.imeStudenta = imeStudenta;
	}
	public String getPrezimeStudenta() {
		return prezimeStudenta;
	}
	public void setPrezimeStudenta(String prezimeStudenta) {
		this.prezimeStudenta = prezimeStudenta;
	}
	public int getBrojIndeksa() {
		return brojIndeksa;
	}
	public void setBrojIndeksa(int brojIndeksa) {
		this.brojIndeksa = brojIndeksa;
	}
	public int getGodinaStudija() {
		return godinaStudija;
	}
	public void setGodinaStudija(int godinaStudija) {
		this.godinaStudija = godinaStudija;
	}
	@Override
	public String toString() {
		return "StudentiDTO [Id=" + Id + ", imeStudenta=" + imeStudenta + ", prezimeStudenta=" + prezimeStudenta
				+ ", brojIndeksa=" + brojIndeksa + ", godinaStudija=" + godinaStudija + "]";
	}
	
	
}
