package itp100.DTO;

public class OglasnaPlocaDTO {

	int Id;
	String OglasnaPloca;
	
	public OglasnaPlocaDTO(int id, String oglasnaPloca) {
		super();
		Id = id;
		OglasnaPloca = oglasnaPloca;
	}

	public OglasnaPlocaDTO() {
		super();
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getOglasnaPloca() {
		return OglasnaPloca;
	}

	public void setOglasnaPloca(String oglasnaPloca) {
		OglasnaPloca = oglasnaPloca;
	}

	@Override
	public String toString() {
		return "OglasnaPlocaDTO [Id=" + Id + ", OglasnaPloca=" + OglasnaPloca + "]";
	}
	
	
}
