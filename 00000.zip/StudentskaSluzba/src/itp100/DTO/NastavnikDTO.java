package itp100.DTO;

public class NastavnikDTO {

	int Id;
	String ime;
	String prezime;
	String zvanje;
	public NastavnikDTO(int id, String ime, String prezime, String zvanje) {
		super();
		Id = id;
		this.ime = ime;
		this.prezime = prezime;
		this.zvanje = zvanje;
	}
	public NastavnikDTO() {
		super();
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getIme() {
		return ime;
	}
	public void setIme(String ime) {
		this.ime = ime;
	}
	public String getPrezime() {
		return prezime;
	}
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}
	public String getZvanje() {
		return zvanje;
	}
	public void setZvanje(String zvanje) {
		this.zvanje = zvanje;
	}
	@Override
	public String toString() {
		return "NastavnikDTO [Id=" + Id + ", ime=" + ime + ", prezime=" + prezime + ", zvanje=" + zvanje + "]";
	}
	
}
