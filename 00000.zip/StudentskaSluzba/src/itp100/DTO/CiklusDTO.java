package itp100.DTO;

public class CiklusDTO {

	int ciklusId; 
	String naziv;
	
	public CiklusDTO(int ciklusId, String naziv) {
		super();
		this.ciklusId = ciklusId;
		this.naziv = naziv;
	}
	

	public CiklusDTO() {
		super();
	}
	public int getCiklusId() {
		return ciklusId;
	}
	public void setCiklusId(int ciklusId) {
		this.ciklusId = ciklusId;
	}
	public String getNaziv() {
		return naziv;
	}
	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}


	public void setCiklusId(int i, CiklusDTO ciklus) {
		
	}
	
	
}
