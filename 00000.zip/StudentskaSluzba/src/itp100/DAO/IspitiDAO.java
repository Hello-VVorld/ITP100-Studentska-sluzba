package itp100.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import itp100.DTO.IspitiDTO;
import itp100.DTO.PredmetDTO;


public class IspitiDAO {

	public static Vector<IspitiDTO> getAll() {
		Vector<IspitiDTO> retVal = new Vector<IspitiDTO>();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM ispiti ";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();

			while (rs.next())
				retVal.add(new IspitiDTO(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getInt(4), rs.getInt(5), rs.getInt(6), rs.getInt(7)));
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
}

	public static boolean dodajIspit(IspitiDTO ip) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "INSERT INTO ispit (id, datum, ocjena, brojBodova, IdNastavnik, Idstudenti, IdStudijskiProgram) VALUES (?, ?, ?, ?, ?, ?, ?)";
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, ip.getId());
			ps.setInt(2, ip.getDatum());
			ps.setString(3, ip.getOcjena());
			ps.setInt(4, ip.getBrojBodova());
			ps.setInt(5, ip.getIdNastavnik());
			ps.setInt(6, ip.getIdStudenti());
			ps.setInt(7, ip.getIdStudijskiProgram());
			

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}
			

	public static boolean azurirajIspit(int Id, int datum, String  ocjena, int brojBodova, int IdNastavnik, int IdStudenta, int IdStudijskiProgram) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "UPDATE ispiti SET datum=? WHERE id_ispit=?";
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, Id);
			ps.setInt(2, datum);
			ps.setString(3, ocjena);
			ps.setInt(4, brojBodova);
			ps.setInt(5, IdNastavnik);
			ps.setInt(6, IdStudenta);
			ps.setInt(7, IdStudijskiProgram);
			
			
			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}
	public static boolean obrisiIspit(int Id) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "DELETE FROM ispiti WHERE id_ispit=?";
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, Id);

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}
	
		public static IspitiDTO getById(int p) {
			IspitiDTO retVal = new IspitiDTO();
			Connection conn = null;
			java.sql.PreparedStatement ps = null;
			ResultSet rs = null;

			String query = "SELECT * FROM ispiti WHERE id_ispit=? ";

			try {
				conn = ConnectionPool.getInstance().checkOut();
				ps = conn.prepareStatement(query);
				rs = ps.executeQuery();

				while (rs.next()) {
					retVal.setId(rs.getInt(1));
					retVal.setDatum(rs.getInt(2));
					retVal.setOcjena(rs.getString(3));
					retVal.setBrojBodova(rs.getInt(4));
					retVal.setIdNastavnik(rs.getInt(5));
					retVal.setIdStudenti(rs.getInt(6));
					retVal.setIdStudijskiProgram(rs.getInt(7));
					
				}
			} catch (SQLException e) {
				e.printStackTrace();
				DBUtilities.getInstance().showSQLException(e);
			} finally {
				ConnectionPool.getInstance().checkIn(conn);
				DBUtilities.getInstance().close(ps, rs);
			}
			return retVal;
	
	
}
}

