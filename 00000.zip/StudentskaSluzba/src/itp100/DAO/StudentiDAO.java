package itp100.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import itp100.DTO.StudentiDTO;


public class StudentiDAO {

	public static Vector<StudentiDTO> getAll() {
		Vector<StudentiDTO> retVal = new Vector<StudentiDTO>();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM studenti ";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();

			while (rs.next())
				retVal.add(new StudentiDTO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getInt(5)));
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
}
	public static boolean dodajStudente(StudentiDTO s) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "INSERT INTO studenti (studenti, ime, prezime, brojIndeksa, godinaStudija) VALUES (?, ?, ?, ?, ?)";
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, s.getId());
			ps.setString(2, s.getImeStudenta());
			ps.setString(3,  s.getPrezimeStudenta());
			ps.setInt(4, s.getBrojIndeksa());
			ps.setInt(5, s.getGodinaStudija());

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}
	public static boolean azurirajStudente(int Id, String imeStudenta, String prezimeStudenta, int brojIndeksa, int godinaStudija) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "UPDATE studenti SET naziv=? WHERE id_studenta=?";
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, Id);
			ps.setString(2, imeStudenta);
			ps.setString(3, prezimeStudenta);
			ps.setInt(4, brojIndeksa);
			ps.setInt(5, godinaStudija);
			
			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}
	public static boolean obrisiStudente(int IdStudenta) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "DELETE FROM studenti WHERE id_studenta=?";
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, IdStudenta);

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}
	
		public static StudentiDTO getById(int s) {
			StudentiDTO retVal = new StudentiDTO();
			Connection conn = null;
			java.sql.PreparedStatement ps = null;
			ResultSet rs = null;

			String query = "SELECT * FROM studenti WHERE id_studenta=? ";

			try {
				conn = ConnectionPool.getInstance().checkOut();
				ps = conn.prepareStatement(query);
				rs = ps.executeQuery();

				while (rs.next()) {
					retVal.setId(rs.getInt(1));
					retVal.setImeStudenta(rs.getString(2));
					retVal.setPrezimeStudenta(rs.getString(3));
					retVal.setBrojIndeksa(rs.getInt(4));
					retVal.setGodinaStudija(rs.getInt(5));
				}
			} catch (SQLException e) {
				e.printStackTrace();
				DBUtilities.getInstance().showSQLException(e);
			} finally {
				ConnectionPool.getInstance().checkIn(conn);
				DBUtilities.getInstance().close(ps, rs);
			}
			return retVal;
	
	
}
}

