package org.itp.studentskasluzba.prikaz.svih.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.itp.studentskasluzba.gui.tablemodel.CiklusTableModel;
import org.itp.studentskasluzba.gui.tablemodel.StudijskiProgramTableModel;

import itp100.DAO.CiklusDAO;
import itp100.DAO.StudijskiProgramDAO;
import itp100.DTO.CiklusDTO;
import itp100.DTO.StudijskiProgramDTO;

import javax.swing.JTable;
import javax.swing.JScrollPane;

public class StudijskiProgramPrikazSvihGUI extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudijskiProgramPrikazSvihGUI frame = new StudijskiProgramPrikazSvihGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudijskiProgramPrikazSvihGUI() {
		setTitle("Prikaz svih studijskih programa");
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//kreiramo listu CiklusDTO objekata
				Vector<StudijskiProgramDTO> studijskiProgrami = StudijskiProgramDAO.getAll();
				List<StudijskiProgramDTO> programiKaoLista= new ArrayList<>(studijskiProgrami);
				
				//kreiranje tableModela
				StudijskiProgramTableModel sptm = new StudijskiProgramTableModel(programiKaoLista);
				
				// proslijedimo table model tabeli kroz kontruktor JTable
				
				
		
		table = new JTable(sptm);
		table.setBounds(10, 11, 414, 240);
		contentPane.add(table);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(411, 11, 2, 5);
		contentPane.add(scrollPane);
	}
}
