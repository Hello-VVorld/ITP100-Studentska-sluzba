package org.itp.studentskasluzba.gui.tablemodel;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import itp100.DTO.CiklusDTO;
import itp100.DTO.IspitiDTO;



public class IspitiTableModel extends AbstractTableModel {
	private List<IspitiDTO> ispiti;
	
	public IspitiTableModel(List<IspitiDTO> ispiti) {
		this.ispiti = ispiti;
		
	}

	@Override
	public int getRowCount() {
		return ispiti.size();
	}

	@Override
	public int getColumnCount() {
		return 7;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		IspitiDTO ispit = ispiti.get(rowIndex);
		Object value = null;
		
		 switch (columnIndex) {
         case 0:
             value = ispit.getId();
             break;
         case 1:
             value = ispit.getDatum();
             break;
         case 2:
             value = ispit.getOcjena();
             break;
         case 3:
             value = ispit.getBrojBodova();
             break;
         case 4:
             value = ispit.getIdNastavnik();
             break;
         case 5:
             value = ispit.getIdStudenti();
             break;
         case 6:
             value = ispit.getIdStudijskiProgram();
             break;
		 }
		return value;
	}
		 @Override
		    public String getColumnName(int column) {
		        String name = "??";
		        switch (column) {
		            case 0:
		                name = "ID";
		                break;
		            case 1:
		                name = "Datum";
		                break;
		            case 2:
		                name = "Ocjena";
		                break;
		            case 3:
		                name = "BrojBodova";
		                break;
		            case 4:
		                name = "IdNastavnik";
		                break;
		            case 5:
		                name = "IdStudenti";
		                break;
		            case 6:
		                name = "IdStudijskiProgram";
		                break;
		            
		        }
		        return name;
		    }
}
