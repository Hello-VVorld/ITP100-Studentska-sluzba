package org.itp.studentskasluzba.gui.tablemodel;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import itp100.DTO.CiklusDTO;
import itp100.DTO.OglasDTO;

public class OglasTableModel extends AbstractTableModel {
	private List<OglasDTO> oglasi;

	public OglasTableModel(List<OglasDTO> oglasi) {
		this.oglasi = oglasi;
		
	}

	@Override
	public int getRowCount() {
		return oglasi.size();
	}

	@Override
	public int getColumnCount() {
		return 6;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		OglasDTO oglas = oglasi.get(rowIndex);
		Object value = null;
		
		 switch (columnIndex) {
         case 0:
             value = oglas.getId();
             break;
         case 1:
             value = oglas.getNaziv();
             break;
         case 2:
             value = oglas.getSadrzaj();
             break;
         case 3:
             value = oglas.getDatum();
             break;
         case 4:
             value = oglas.isAktivan();
             break;
         case 5:
             value = oglas.getOglasnaPloca();
             break;
       
     }
		return value;
	}
	@Override
    public String getColumnName(int column) {
        String name = "??";
        switch (column) {
            case 0:
                name = "ID";
                break;
            case 1:
                name = "Naziv";
                break;
            case 2:
                name = "Sadrzaj";
                break; 
            case 3:
            	name = "Datum";
            case 4:
            	name = "Aktivan";
            case 5:
                name = "OglasnaPloca";
                break;
        }
        return name;
    }
}
