package org.itp.studentskasluzba.gui.tablemodel;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import itp100.DTO.CiklusDTO;
import itp100.DTO.StudijskiProgramDTO;

public class StudijskiProgramTableModel extends AbstractTableModel {
	private List<StudijskiProgramDTO> studijskiProgrami;
	
	public StudijskiProgramTableModel(List<StudijskiProgramDTO> studijskiProgrami) {
		this.studijskiProgrami = studijskiProgrami;


	}

	@Override
	public int getRowCount() {
		return studijskiProgrami.size();
	}

	@Override
	public int getColumnCount() {
		return 3;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		StudijskiProgramDTO studijskiProgram = studijskiProgrami.get(rowIndex);
		Object value = null;
		
		 switch (columnIndex) {
         case 0:
             value = studijskiProgram.getId();
             break;
         case 1:
             value = studijskiProgram.getNaziv();
             break;
         case 2:
        	 value = studijskiProgram.getCiklus();
       
     }
     return value;
		
	}
	 @Override
	    public String getColumnName(int column) {
	        String name = "??";
	        switch (column) {
	            case 0:
	                name = "ID";
	                break;
	            case 1:
	                name = "Naziv";
	                break;
	            case 2:
	            	name = "Ciklus";
	            
	        }
	        return name;
	    }

	}


