package org.itp.studentskasluzba.gui.tablemodel;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import itp100.DTO.CiklusDTO;
import itp100.DTO.OglasnaPlocaDTO;

public class OglasnaPlocaTableModel extends AbstractTableModel {
	private List<OglasnaPlocaDTO> oglasnaPl;

	public OglasnaPlocaTableModel(List<OglasnaPlocaDTO> oglasnaPl) {
		this.oglasnaPl = oglasnaPl;
	}

	@Override
	public int getRowCount() {

		return oglasnaPl.size();
	}

	@Override
	public int getColumnCount() {
		return 2;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		OglasnaPlocaDTO oglasnaPloca = oglasnaPl.get(rowIndex);
		Object value = null;
		
		 switch (columnIndex) {
         case 0:
             value = oglasnaPloca.getId();
             break;
         case 1:
             value =oglasnaPloca.getOglasnaPloca();
             break;
       
     }
     return value;
		
		
	}
	 @Override
	    public String getColumnName(int column) {
	        String name = "??";
	        switch (column) {
	            case 0:
	                name = "ID";
	                break;
	            case 1:
	                name = "OglasnaPloca";
	                break;
	            
	        }
	        return name;
	    }
}
