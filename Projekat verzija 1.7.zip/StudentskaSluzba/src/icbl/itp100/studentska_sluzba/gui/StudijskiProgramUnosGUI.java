package icbl.itp100.studentska_sluzba.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.CiklusDAO;
import icbl.itp100.studentska_sluzba.dao.StudijskiProgramDAO;
import icbl.itp100.studentska_sluzba.dto.CiklusDTO;
import icbl.itp100.studentska_sluzba.dto.StudijskiProgramDTO;

import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Vector;
import java.awt.event.ActionEvent;

public class StudijskiProgramUnosGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JButton btnUnesi;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudijskiProgramUnosGUI frame = new StudijskiProgramUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudijskiProgramUnosGUI() {
		setTitle("Studijski program | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblUnesiteNaziv = new JLabel("Unesite naziv:");
		lblUnesiteNaziv.setBounds(10, 11, 157, 14);
		contentPane.add(lblUnesiteNaziv);

		textField = new JTextField();
		textField.setBounds(4, 36, 315, 20);
		contentPane.add(textField);
		textField.setColumns(10);

		JLabel lblOdaberiteCiklus = new JLabel("Odaberite ciklus:");
		lblOdaberiteCiklus.setBounds(10, 65, 157, 14);
		contentPane.add(lblOdaberiteCiklus);

		Vector<CiklusDTO> sviCiklusi = CiklusDAO.getAll();

		JComboBox comboBox = new JComboBox(sviCiklusi);
		comboBox.setBounds(10, 90, 157, 22);
		contentPane.add(comboBox);

		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String nazivSP = textField.getText();
				String ciklus = comboBox.getSelectedItem().toString();
				String parsiranCiklus[] = ciklus.split("-");
				int idCiklus = Integer.parseInt(parsiranCiklus[0]);
				StudijskiProgramDTO sp = new StudijskiProgramDTO();
				sp.setNazivSP(nazivSP);
				sp.setCiklusFK(idCiklus);
				boolean uspjesno = StudijskiProgramDAO.dodajStudijskiProgram(sp);
				String bool = uspjesno ? "Uspjesno ste dodali studijski program."
						: "Dogodila se greska pri dodavanju studijskog programa.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		btnUnesi.setBounds(333, 228, 91, 23);
		contentPane.add(btnUnesi);
		
	}
	
}
