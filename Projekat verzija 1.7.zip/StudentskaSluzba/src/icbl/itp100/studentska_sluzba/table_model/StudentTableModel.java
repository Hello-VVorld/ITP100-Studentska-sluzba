package icbl.itp100.studentska_sluzba.table_model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import icbl.itp100.studentska_sluzba.dto.StudentDTO;

public class StudentTableModel extends AbstractTableModel {
	private List<StudentDTO> studenti;

	public StudentTableModel(List<StudentDTO> studenti) {
		this.studenti = studenti;
	}

	@Override
	public int getRowCount() {
		return studenti.size();
	}

	@Override
	public int getColumnCount() {
		return 5;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		StudentDTO student = studenti.get(rowIndex);
		Object value = null;

		switch (columnIndex) {
		case 0:
			value = student.getStudentID();
			break;
		case 1:
			value = student.getImeStudenta();
			break;
		case 2:
			value = student.getPrezimeStudenta();
			break;
		case 3:
			value = student.getBrojIndeksa();
			break;
		case 4:
			value = student.getGodinaUpisa();
			break;
		}

		return value;
	}

	@Override
	public String getColumnName(int column) {
		String name = "??";
		switch (column) {
		case 0:
			name = "ID";
			break;
		case 1:
			name = "Ime";
			break;
		case 2:
			name = "Prezime";
			break;
		case 3:
			name = "Broj indeksa";
			break;
		case 4:
			name = "Godina upisa";
			break;
		}
		return name;
	}
	
}
