package icbl.itp100.studentska_sluzba.table_model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import icbl.itp100.studentska_sluzba.dto.StudijskiProgramDTO;

public class StudijskiProgramTableModel extends AbstractTableModel {
	private List<StudijskiProgramDTO> studijskiProgrami;

	public StudijskiProgramTableModel(List<StudijskiProgramDTO> studijskiProgrami) {
		this.studijskiProgrami = studijskiProgrami;
	}

	@Override
	public int getRowCount() {
		return studijskiProgrami.size();
	}

	@Override
	public int getColumnCount() {
		return 3;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		StudijskiProgramDTO studijskiProgram = studijskiProgrami.get(rowIndex);
		Object value = null;

		switch (columnIndex) {
		case 0:
			value = studijskiProgram.getStudijskiProgramID();
			break;
		case 1:
			value = studijskiProgram.getNazivSP();
			break;
		case 2:
			value = studijskiProgram.getCiklusFK();
			break;
		}
		
		return value;
	}

	@Override
	public String getColumnName(int column) {
		String name = "??";
		switch (column) {
		case 0:
			name = "ID";
			break;
		case 1:
			name = "Naziv";
			break;
		case 2:
			name = "Ciklus";
			break;
		}
		return name;
	}

}
