package icbl.itp100.studentska_sluzba.dto;

public class OglasDTO {

	int oglasID;
	String nazivOglasa;
	String sadrzaj;
	String datum;
	boolean aktivan;
	int oglasnaPlocaFK;

	public OglasDTO(int oglasID, String nazivOglasa, String sadrzaj, String datum, boolean aktivan,
			int oglasnaPlocaFK) {
		super();
		this.oglasID = oglasID;
		this.nazivOglasa = nazivOglasa;
		this.sadrzaj = sadrzaj;
		this.datum = datum;
		this.aktivan = aktivan;
		this.oglasnaPlocaFK = oglasnaPlocaFK;
	}

	public OglasDTO() {
		super();
	}

	public int getOglasID() {
		return oglasID;
	}

	public void setOglasID(int oglasID) {
		this.oglasID = oglasID;
	}

	public String getNazivOglasa() {
		return nazivOglasa;
	}

	public void setNazivOglasa(String nazivOglasa) {
		this.nazivOglasa = nazivOglasa;
	}

	public String getSadrzaj() {
		return sadrzaj;
	}

	public void setSadrzaj(String sadrzaj) {
		this.sadrzaj = sadrzaj;
	}

	public String getDatum() {
		return datum;
	}

	public void setDatum(String datum) {
		this.datum = datum;
	}

	public boolean isAktivan() {
		return aktivan;
	}

	public void setAktivan(boolean aktivan) {
		this.aktivan = aktivan;
	}

	public int getOglasnaPlocaFK() {
		return oglasnaPlocaFK;
	}

	public void setOglasnaPlocaFK(int oglasnaPlocaFK) {
		this.oglasnaPlocaFK = oglasnaPlocaFK;
	}

	@Override
	public String toString() {
		return oglasID + " - " + nazivOglasa;
	}

}
