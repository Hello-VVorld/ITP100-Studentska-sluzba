package icbl.itp100.studentska_sluzba.dto;

public class IspitDTO {

	int ispitID;
	String datumIspita;
	int ocjena;
	int brojBodova;
	int studentFK;
	int predmetFK;
	int nastavnikFK;
	int studijskiProgramFK;

	public IspitDTO(int ispitID, String datumIspita, int ocjena, int brojBodova, int studentFK, int predmetFK,
			int nastavnikFK, int studijskiProgramFK) {
		super();
		this.ispitID = ispitID;
		this.datumIspita = datumIspita;
		this.ocjena = ocjena;
		this.brojBodova = brojBodova;
		this.studentFK = studentFK;
		this.predmetFK = predmetFK;
		this.nastavnikFK = nastavnikFK;
		this.studijskiProgramFK = studijskiProgramFK;
	}

	public IspitDTO() {
		super();
	}

	public int getIspitID() {
		return ispitID;
	}

	public void setIspitID(int ispitID) {
		this.ispitID = ispitID;
	}

	public String getDatumIspita() {
		return datumIspita;
	}

	public void setDatumIspita(String datumIspita) {
		this.datumIspita = datumIspita;
	}

	public int getOcjena() {
		return ocjena;
	}

	public void setOcjena(int ocjena) {
		this.ocjena = ocjena;
	}

	public int getBrojBodova() {
		return brojBodova;
	}

	public void setBrojBodova(int brojBodova) {
		this.brojBodova = brojBodova;
	}

	public int getStudentFK() {
		return studentFK;
	}

	public void setStudentFK(int studentFK) {
		this.studentFK = studentFK;
	}

	public int getPredmetFK() {
		return predmetFK;
	}

	public void setPredmetFK(int predmetFK) {
		this.predmetFK = predmetFK;
	}

	public int getNastavnikFK() {
		return nastavnikFK;
	}

	public void setNastavnikFK(int nastavnikFK) {
		this.nastavnikFK = nastavnikFK;
	}

	public int getStudijskiProgramFK() {
		return studijskiProgramFK;
	}

	public void setStudijskiProgramFK(int studijskiProgramFK) {
		this.studijskiProgramFK = studijskiProgramFK;
	}

	@Override
	public String toString() {
		return ispitID + " - " + datumIspita;
	}

}
