package icbl.itp100.studentska_sluzba.table_model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import icbl.itp100.studentska_sluzba.dao.NastavnikDAO;
import icbl.itp100.studentska_sluzba.dao.PredmetDAO;
import icbl.itp100.studentska_sluzba.dao.StudentDAO;
import icbl.itp100.studentska_sluzba.dao.StudijskiProgramDAO;
import icbl.itp100.studentska_sluzba.dto.IspitDTO;
import icbl.itp100.studentska_sluzba.dto.NastavnikDTO;
import icbl.itp100.studentska_sluzba.dto.PredmetDTO;
import icbl.itp100.studentska_sluzba.dto.StudentDTO;
import icbl.itp100.studentska_sluzba.dto.StudijskiProgramDTO;

public class IspitTableModel extends AbstractTableModel {
	private static final long serialVersionUID = 5029216042029047586L;
	private List<IspitDTO> ispiti;
	public IspitTableModel(List<IspitDTO> ispiti) {
		this.ispiti = ispiti;
	}

	@Override
	public int getRowCount() {
		return ispiti.size();
	}

	@Override
	public int getColumnCount() {
		return 8;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		IspitDTO ispit = ispiti.get(rowIndex);
		Object value = null;

		switch (columnIndex) {
		case 0:
			value = ispit.getIspitID();
			break;
		case 1:
			value = ispit.getDatumIspita();
			break;
		case 2:
			value = ispit.getOcjena();
			break;
		case 3:
			value = ispit.getBrojBodova();
			break;
		case 4:
			StudentDTO s = new StudentDTO();
			s = StudentDAO.getByID(ispit.getStudentFK());
			value = s.getImeStudenta() +" "+ s.getImeStudenta();
			break;
		case 5:
			PredmetDTO p = new PredmetDTO();
			p = PredmetDAO.getByID(ispit.getPredmetFK());
			value = p.getNazivPredmeta();
			break;
		case 6:
			NastavnikDTO n = new NastavnikDTO();
			n = NastavnikDAO.getByID(ispit.getNastavnikFK());
			value = n.getImeNastavnika() + " " + n.getPrezimeNastavnika();
			break;
		case 7:
			StudijskiProgramDTO sp = new StudijskiProgramDTO();
			sp = StudijskiProgramDAO.getByID(ispit.getStudijskiProgramFK());
			value = sp.getNazivSP();
			break;
		}

		return value;
	}

	@Override
	public String getColumnName(int column) {
		String name = "??";
		switch (column) {
		case 0:
			name = "ID";
			break;
		case 1:
			name = "Datum";
			break;
		case 2:
			name = "Ocjena";
			break;
		case 3:
			name = "Broj bodova";
			break;
		case 4:
			name = "Student";
			break;
		case 5:
			name = "Predmet";
			break;
		case 6:
			name = "Nastavnik";
			break;
		case 7:
			name = "Studijski program";
			break;
		}
		return name;
	}

}
