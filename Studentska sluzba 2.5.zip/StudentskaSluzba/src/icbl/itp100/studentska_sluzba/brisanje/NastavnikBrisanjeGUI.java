package icbl.itp100.studentska_sluzba.brisanje;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import icbl.itp100.studentska_sluzba.dao.NastavnikDAO;
import icbl.itp100.studentska_sluzba.dto.NastavnikDTO;
import icbl.itp100.studentska_sluzba.ispis.gui.CiklusIspisGUI;
import icbl.itp100.studentska_sluzba.ispis.gui.IspitIspisGUI;
import icbl.itp100.studentska_sluzba.ispis.gui.NastavnikIspisGUI;
import icbl.itp100.studentska_sluzba.ispis.gui.OglasIspisGUI;
import icbl.itp100.studentska_sluzba.ispis.gui.OglasnaPlocaIspisGUI;
import icbl.itp100.studentska_sluzba.ispis.gui.PredmetIspisGUI;
import icbl.itp100.studentska_sluzba.ispis.gui.StudentIspisGUI;
import icbl.itp100.studentska_sluzba.ispis.gui.StudijskiProgramIspisGUI;
import icbl.itp100.studentska_sluzba.unos.gui.CiklusUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.IspitUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.NastavnikUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.OglasUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.OglasnaPlocaUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.PredmetUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.StudentUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.StudijskiProgramUnosGUI;

public class NastavnikBrisanjeGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3561341465084472376L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NastavnikBrisanjeGUI frame = new NastavnikBrisanjeGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public NastavnikBrisanjeGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 633, 429);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		
		
		
		
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(10, 11, 207, 21);
		menuBar.setToolTipText("");
		contentPane.add(menuBar);
		JMenu meni = new JMenu("Dodaj");
		menuBar.add(meni);
		JMenuItem studentMeni = new JMenuItem("Studenti");
		studentMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentUnosGUI sg = new StudentUnosGUI();
				sg.setVisible(true);
			}
		});
		meni.add(studentMeni);
		JMenuItem ciklusMeni = new JMenuItem("Ciklus");
		ciklusMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CiklusUnosGUI cug = new CiklusUnosGUI();
				cug.setVisible(true);
			}
		});
		meni.add(ciklusMeni);
		JMenuItem ispitMeni = new JMenuItem("Ispit");
		ispitMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IspitUnosGUI iug = new IspitUnosGUI();
				iug.setVisible(true);
			}
		});
		meni.add(ispitMeni);
		JMenuItem oglasnaPlocaMeni = new JMenuItem("Oglasna Ploca");
		oglasnaPlocaMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasnaPlocaUnosGUI opg = new OglasnaPlocaUnosGUI();
				opg.setVisible(true);
			}
		});
		meni.add( oglasnaPlocaMeni);
		JMenuItem oglasMeni = new JMenuItem("Oglas");
		oglasMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasUnosGUI og = new OglasUnosGUI();
				og.setVisible(true);
			}
		});
		meni.add(oglasMeni);
		JMenuItem predmetMeni = new JMenuItem("Predmet");
		predmetMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PredmetUnosGUI pg = new PredmetUnosGUI();
				pg.setVisible(true);
			}
		});
		meni.add(predmetMeni);
		JMenuItem studijskiProgramMeni = new JMenuItem("Studijski Program");
		studijskiProgramMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudijskiProgramUnosGUI spg = new StudijskiProgramUnosGUI();
				spg.setVisible(true);
			}
		});
		meni.add(studijskiProgramMeni);
		JMenuItem nastavnikMeni = new JMenuItem("Nastavnik");
		nastavnikMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NastavnikUnosGUI ng = new NastavnikUnosGUI();
				ng.setVisible(true);
			}
		});
		meni.add(nastavnikMeni);
		
		JMenu meniTable = new JMenu("Ispis tabela");
		menuBar.add(meniTable );
		JMenuItem studentMeniIspis = new JMenuItem("Studenti");
		studentMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentIspisGUI sgi = new StudentIspisGUI();
				sgi.setVisible(true);
			}
		});
		meniTable.add(studentMeniIspis);
		
		
		JMenuItem ciklusMeniIspis = new JMenuItem("Ciklus");
		ciklusMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CiklusIspisGUI cgi = new CiklusIspisGUI();
				cgi.setVisible(true);
			}
		});
		meniTable.add(ciklusMeniIspis);
		
		
		JMenuItem ispitMeniIspis = new JMenuItem("Ispit");
		ispitMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IspitIspisGUI igi = new IspitIspisGUI();
				igi.setVisible(true);
			}
		});
		meniTable.add(ispitMeniIspis);
		
		
		JMenuItem oglasnaPlocaMeniIspis = new JMenuItem("Oglasna Ploca");
		oglasnaPlocaMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasnaPlocaIspisGUI opgi = new OglasnaPlocaIspisGUI();
				opgi.setVisible(true);
			}
		});
		meniTable.add(oglasnaPlocaMeniIspis);
		
		
		JMenuItem oglasMeniIspis = new JMenuItem("Oglas");
		oglasMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasIspisGUI ogio = new OglasIspisGUI();
				ogio.setVisible(true);
			}
		});
		meniTable.add(oglasMeniIspis);
		
		
		JMenuItem predmetMeniIspis = new JMenuItem("Predmet");
		predmetMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PredmetIspisGUI pgi = new PredmetIspisGUI();
				pgi.setVisible(true);
			}
		});
		meniTable.add(predmetMeniIspis);
		
		
		JMenuItem studijskiProgramMeniIspis = new JMenuItem("Studijski Program");
		studijskiProgramMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudijskiProgramIspisGUI spgi = new StudijskiProgramIspisGUI();
				spgi.setVisible(true);
			}
		});
		meniTable.add(studijskiProgramMeniIspis);
		
		
		JMenuItem nastavnikMeniIspis = new JMenuItem("Nastavnik");
		nastavnikMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NastavnikIspisGUI ngi = new NastavnikIspisGUI();
				ngi.setVisible(true);
			}
		});
		meniTable.add(nastavnikMeniIspis);
		
		
		
		
		JLabel lblNewLabel = new JLabel("Ispis nastavnika:");
		lblNewLabel.setBounds(10, 70, 76, 14);
		contentPane.add(lblNewLabel);
		
		Vector<NastavnikDTO> sviNastavnici =NastavnikDAO.getAll();
		JComboBox comboBox = new JComboBox(sviNastavnici);
		comboBox.setBounds(10, 95, 151, 22);
		contentPane.add(comboBox);
		
		JButton btnObrisi = new JButton("Obrisi");
		btnObrisi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				int nastavniciIspisAB = Integer.parseInt(comboBox.getSelectedItem().toString().split(" - ")[0]);
				boolean uspjesnoDodavanje = NastavnikDAO.obrisiNastavnik(nastavniciIspisAB);
				if (uspjesnoDodavanje) {
					JOptionPane.showMessageDialog(null, "Uspjesno te obrisali nastavnika!");
				} else
					JOptionPane.showMessageDialog(null, "Dogodila se greska pri brisanju nastavnika!");
			}
			
		});
		btnObrisi.setBounds(10, 368, 91, 23);
		contentPane.add(btnObrisi);
		
		JLabel lblNapomenaPodatakIz = new JLabel("Napomena:  Podatak iz ciklusa koristen u nekoj od ostalih tabela se ne moze obrisati.");
		lblNapomenaPodatakIz.setBounds(10, 140, 605, 21);
		contentPane.add(lblNapomenaPodatakIz);
		
		JLabel lblProvjeriteOstaleTabele = new JLabel(" Provjerite ostale tabele, obrisite i onda ce vam biti omoguceno u ciklusu da obrisete.");
		lblProvjeriteOstaleTabele.setBounds(10, 162, 605, 14);
		contentPane.add(lblProvjeriteOstaleTabele);
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
