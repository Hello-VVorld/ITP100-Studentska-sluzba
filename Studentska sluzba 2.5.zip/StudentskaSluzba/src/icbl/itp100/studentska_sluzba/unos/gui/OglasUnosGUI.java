package icbl.itp100.studentska_sluzba.unos.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import icbl.itp100.studentska_sluzba.dao.OglasDAO;
import icbl.itp100.studentska_sluzba.dao.OglasnaPlocaDAO;
import icbl.itp100.studentska_sluzba.dto.OglasDTO;
import icbl.itp100.studentska_sluzba.dto.OglasnaPlocaDTO;
import icbl.itp100.studentska_sluzba.ispis.gui.OglasIspisGUI;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Vector;
import java.awt.event.ActionEvent;

public class OglasUnosGUI extends JFrame {
	private static final long serialVersionUID = -8797379446212868041L;
	private JPanel contentPane;
	private JTextField tfNaziv;
	private JTextField textField;
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OglasUnosGUI frame = new OglasUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public OglasUnosGUI() {
		setTitle("Oglas | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 633, 429);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(408, 24, 207, 21);
		menuBar.setToolTipText("");
		contentPane.add(menuBar);
		JMenu meni = new JMenu("Meni");
		menuBar.add(meni);
		JMenuItem studentMeni = new JMenuItem("Studenti");
		studentMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentUnosGUI sg = new StudentUnosGUI();
				sg.setVisible(true);
			}
		});
		meni.add(studentMeni);
		JMenuItem ciklusMeni = new JMenuItem("Ciklus");
		ciklusMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CiklusUnosGUI cug = new CiklusUnosGUI();
				cug.setVisible(true);
			}
		});
		meni.add(ciklusMeni);
		JMenuItem ispitMeni = new JMenuItem("Ispit");
		ispitMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IspitUnosGUI iug = new IspitUnosGUI();
				iug.setVisible(true);
			}
		});
		meni.add(ispitMeni);
		JMenuItem oglasnaPlocaMeni = new JMenuItem("Oglasna Ploca");
		oglasnaPlocaMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasnaPlocaUnosGUI opg = new OglasnaPlocaUnosGUI();
				opg.setVisible(true);
			}
		});
		meni.add( oglasnaPlocaMeni);
		JMenuItem oglasMeni = new JMenuItem("Oglas");
		oglasMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasUnosGUI og = new OglasUnosGUI();
				og.setVisible(true);
			}
		});
		meni.add(oglasMeni);
		JMenuItem predmetMeni = new JMenuItem("Predmet");
		predmetMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PredmetUnosGUI pg = new PredmetUnosGUI();
				pg.setVisible(true);
			}
		});
		meni.add(predmetMeni);
		JMenuItem studijskiProgramMeni = new JMenuItem("Studijski Program");
		studijskiProgramMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudijskiProgramUnosGUI spg = new StudijskiProgramUnosGUI();
				spg.setVisible(true);
			}
		});
		meni.add(studijskiProgramMeni);
		JMenuItem nastavnikMeni = new JMenuItem("Nastavnik");
		nastavnikMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NastavnikUnosGUI ng = new NastavnikUnosGUI();
				ng.setVisible(true);
			}
		});
		meni.add(nastavnikMeni);
		

		JLabel lblNaziv = new JLabel("Naziv:");
		lblNaziv.setBounds(10, 39, 53, 14);
		contentPane.add(lblNaziv);

		tfNaziv = new JTextField();
		tfNaziv.setBounds(10, 64, 300, 20);
		contentPane.add(tfNaziv);
		tfNaziv.setColumns(10);

		JLabel lblSadrzaj = new JLabel("Sadrzaj:");
		lblSadrzaj.setBounds(10, 95, 157, 14);
		contentPane.add(lblSadrzaj);

		JTextArea taSadrzaj = new JTextArea();
		taSadrzaj.setBounds(10, 120, 300, 81);
		contentPane.add(taSadrzaj);

		JLabel lblVrstaOglasa = new JLabel("Vrsta oglasa:");
		lblVrstaOglasa.setBounds(10, 212, 157, 14);
		contentPane.add(lblVrstaOglasa);

		Vector<OglasnaPlocaDTO> sviOglasi = OglasnaPlocaDAO.getAll();

		JComboBox cbVrstaOglasa = new JComboBox(sviOglasi);
		cbVrstaOglasa.setBounds(10, 237, 157, 22);
		contentPane.add(cbVrstaOglasa);

		JLabel lblDatum = new JLabel("Datum:");
		lblDatum.setBounds(177, 212, 89, 14);
		contentPane.add(lblDatum);
		
		textField = new JTextField();
		textField.setBounds(167, 238, 143, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"1", "2"}));
		comboBox.setBounds(10, 307, 53, 22);
		contentPane.add(comboBox);
		
		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String nazivOglasa = tfNaziv.getText();
				String sadrzaj = taSadrzaj.getText();
				int idOglas = Integer.parseInt(cbVrstaOglasa.getSelectedItem().toString().split(" - ")[0]);
				
				String datum = textField.getText();
				int bol = comboBox.getSelectedIndex();
				boolean status = bol==1 ? false: true;
				
				OglasDTO oglasZaUnos = new OglasDTO(0, nazivOglasa, sadrzaj, datum, status, idOglas);
				boolean uspjesno = OglasDAO.dodajOglas(oglasZaUnos);
				String bool = uspjesno ? "Uspjesno ste dodali oglas!" : "Dogodila se greska pri dodavanju oglasa!";
				JOptionPane.showMessageDialog(null, bool);

			}
		});
		btnUnesi.setBounds(526, 368, 89, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazSvihOglasa = new JButton("Prikaz svih oglasa");
		btnPrikazSvihOglasa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OglasIspisGUI prikazSvih=new OglasIspisGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazSvihOglasa.setBounds(0, 368, 186, 23);
		contentPane.add(btnPrikazSvihOglasa);
		
		JLabel lblStatus = new JLabel("Status:");
		lblStatus.setBounds(10, 282, 48, 14);
		contentPane.add(lblStatus);
		

		

		
	}
}
