package icbl.itp100.studentska_sluzba.unos.gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.PredmetDAO;
import icbl.itp100.studentska_sluzba.dto.PredmetDTO;
import icbl.itp100.studentska_sluzba.ispis.gui.PredmetIspisGUI;

public class PredmetUnosGUI extends JFrame {
	private static final long serialVersionUID = 8088736992199417306L;
	private JPanel contentPane;
	private JTextField tfNaziv;
	private JTextField tfEcts;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PredmetUnosGUI frame = new PredmetUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public PredmetUnosGUI() {
		setTitle("Predmet | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 633, 429);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(408, 11, 207, 21);
		menuBar.setToolTipText("");
		contentPane.add(menuBar);
		JMenu meni = new JMenu("Meni");
		menuBar.add(meni);
		JMenuItem studentMeni = new JMenuItem("Studenti");
		studentMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentUnosGUI sg = new StudentUnosGUI();
				sg.setVisible(true);
			}
		});
		meni.add(studentMeni);
		JMenuItem ciklusMeni = new JMenuItem("Ciklus");
		ciklusMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CiklusUnosGUI cug = new CiklusUnosGUI();
				cug.setVisible(true);
			}
		});
		meni.add(ciklusMeni);
		JMenuItem ispitMeni = new JMenuItem("Ispit");
		ispitMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IspitUnosGUI iug = new IspitUnosGUI();
				iug.setVisible(true);
			}
		});
		meni.add(ispitMeni);
		JMenuItem oglasnaPlocaMeni = new JMenuItem("Oglasna Ploca");
		oglasnaPlocaMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasnaPlocaUnosGUI opg = new OglasnaPlocaUnosGUI();
				opg.setVisible(true);
			}
		});
		meni.add( oglasnaPlocaMeni);
		JMenuItem oglasMeni = new JMenuItem("Oglas");
		oglasMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasUnosGUI og = new OglasUnosGUI();
				og.setVisible(true);
			}
		});
		meni.add(oglasMeni);
		JMenuItem predmetMeni = new JMenuItem("Predmet");
		predmetMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PredmetUnosGUI pg = new PredmetUnosGUI();
				pg.setVisible(true);
			}
		});
		meni.add(predmetMeni);
		JMenuItem studijskiProgramMeni = new JMenuItem("Studijski Program");
		studijskiProgramMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudijskiProgramUnosGUI spg = new StudijskiProgramUnosGUI();
				spg.setVisible(true);
			}
		});
		meni.add(studijskiProgramMeni);
		JMenuItem nastavnikMeni = new JMenuItem("Nastavnik");
		nastavnikMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NastavnikUnosGUI ng = new NastavnikUnosGUI();
				ng.setVisible(true);
			}
		});
		meni.add(nastavnikMeni);
		
		
		JLabel lblNaziv = new JLabel("Naziv:");
		lblNaziv.setBounds(10, 40, 41, 14);
		contentPane.add(lblNaziv);

		tfNaziv = new JTextField();
		tfNaziv.setBounds(10, 62, 300, 20);
		contentPane.add(tfNaziv);
		tfNaziv.setColumns(10);

		JLabel lblObavezan = new JLabel("Obavezan / Izborni:");
		lblObavezan.setBounds(10, 93, 157, 14);
		contentPane.add(lblObavezan);

		JComboBox cbObavezan = new JComboBox();
		cbObavezan.setModel(new DefaultComboBoxModel(new String[] {"1", "2"}));
		cbObavezan.setBounds(10, 118, 157, 22);
		contentPane.add(cbObavezan);

		JLabel lblEcts = new JLabel("ECTS:");
		lblEcts.setBounds(10, 151, 101, 14);
		contentPane.add(lblEcts);

		tfEcts = new JTextField();
		tfEcts.setBounds(10, 176, 71, 20);
		contentPane.add(tfEcts);
		tfEcts.setColumns(10);

		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String nazivPredmeta = tfNaziv.getText();
				int ects = Integer.parseInt(tfEcts.getText());
				int bol = cbObavezan.getSelectedIndex();
				boolean status = bol==1 ? true : false;
				PredmetDTO pr = new PredmetDTO();
				pr.setNazivPredmeta(nazivPredmeta);
				pr.setObavezan(status);
				pr.setEcts(ects);
				boolean uspjesno = PredmetDAO.dodajPredmet(pr);
				String bool = uspjesno ? "Uspjesno ste dodali predmet." : "Dogodila se greska pri dodavanju predmeta.";
				JOptionPane.showMessageDialog(null, bool);

			}
		});
		btnUnesi.setBounds(526, 368, 89, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazSvihPredmeta = new JButton("Prikaz svih predmeta");
		btnPrikazSvihPredmeta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PredmetIspisGUI prikazSvih=new PredmetIspisGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazSvihPredmeta.setBounds(10, 368, 186, 23);
		contentPane.add(btnPrikazSvihPredmeta);

	}

}
