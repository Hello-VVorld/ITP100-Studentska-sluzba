package icbl.itp100.studentska_sluzba.unos.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.NastavnikDAO;
import icbl.itp100.studentska_sluzba.dto.NastavnikDTO;
import icbl.itp100.studentska_sluzba.ispis.gui.NastavnikIspisGUI;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NastavnikUnosGUI extends JFrame {
	private static final long serialVersionUID = 8420235173041636410L;
	private JPanel contentPane;
	private JTextField tfIme;
	private JTextField tfPrezime;
	private JTextField tfZvanje;
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NastavnikUnosGUI frame = new NastavnikUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public NastavnikUnosGUI() {
		setTitle("Nastavnik | Upis");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 633, 429);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(408, 11, 207, 21);
		menuBar.setToolTipText("");
		contentPane.add(menuBar);
		JMenu meni = new JMenu("Meni");
		menuBar.add(meni);
		JMenuItem studentMeni = new JMenuItem("Studenti");
		studentMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentUnosGUI sg = new StudentUnosGUI();
				sg.setVisible(true);
			}
		});
		meni.add(studentMeni);
		JMenuItem ciklusMeni = new JMenuItem("Ciklus");
		ciklusMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CiklusUnosGUI cug = new CiklusUnosGUI();
				cug.setVisible(true);
			}
		});
		meni.add(ciklusMeni);
		JMenuItem ispitMeni = new JMenuItem("Ispit");
		ispitMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IspitUnosGUI iug = new IspitUnosGUI();
				iug.setVisible(true);
			}
		});
		meni.add(ispitMeni);
		JMenuItem oglasnaPlocaMeni = new JMenuItem("Oglasna Ploca");
		oglasnaPlocaMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasnaPlocaUnosGUI opg = new OglasnaPlocaUnosGUI();
				opg.setVisible(true);
			}
		});
		meni.add( oglasnaPlocaMeni);
		JMenuItem oglasMeni = new JMenuItem("Oglas");
		oglasMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasUnosGUI og = new OglasUnosGUI();
				og.setVisible(true);
			}
		});
		meni.add(oglasMeni);
		JMenuItem predmetMeni = new JMenuItem("Predmet");
		predmetMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PredmetUnosGUI pg = new PredmetUnosGUI();
				pg.setVisible(true);
			}
		});
		meni.add(predmetMeni);
		JMenuItem studijskiProgramMeni = new JMenuItem("Studijski Program");
		studijskiProgramMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudijskiProgramUnosGUI spg = new StudijskiProgramUnosGUI();
				spg.setVisible(true);
			}
		});
		meni.add(studijskiProgramMeni);
		JMenuItem nastavnikMeni = new JMenuItem("Nastavnik");
		nastavnikMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NastavnikUnosGUI ng = new NastavnikUnosGUI();
				ng.setVisible(true);
			}
		});
		meni.add(nastavnikMeni);
		
		
		JLabel lblIme = new JLabel("Ime:");
		lblIme.setBounds(10, 46, 42, 14);
		contentPane.add(lblIme);
		
		tfIme = new JTextField();
		tfIme.setBounds(10, 65, 300, 20);
		contentPane.add(tfIme);
		tfIme.setColumns(10);
		
		JLabel lblPrezime = new JLabel("Prezime:");
		lblPrezime.setBounds(10, 95, 91, 14);
		contentPane.add(lblPrezime);
		
		tfPrezime = new JTextField();
		tfPrezime.setBounds(10, 120, 300, 20);
		contentPane.add(tfPrezime);
		tfPrezime.setColumns(10);
		
		JLabel lblZvanje = new JLabel("Zvanje:");
		lblZvanje.setBounds(10, 151, 149, 14);
		contentPane.add(lblZvanje);
		
		tfZvanje = new JTextField();
		tfZvanje.setBounds(10, 176, 149, 20);
		contentPane.add(tfZvanje);
		tfZvanje.setColumns(10);
		
		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String imeNastavnika = tfIme.getText();
				String prezimeNastavnika = tfPrezime.getText();
				String zvanjeNastavnika = tfZvanje.getText();
				
				NastavnikDTO n = new NastavnikDTO();
				n.setImeNastavnika(imeNastavnika);
				n.setPrezimeNastavnika(prezimeNastavnika);
				n.setZvanje(zvanjeNastavnika);
				boolean uspjesno = NastavnikDAO.dodajNastavnik(n);
				String bool = uspjesno ? "Uspjesno ste dodali nastavnika." : "Dogodila se greska pri dodavanju nastavnika.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		btnUnesi.setBounds(524, 368, 91, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazSvihNastavnika = new JButton("Prikaz svih nastavnika");
		btnPrikazSvihNastavnika.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NastavnikIspisGUI prikazSvih=new NastavnikIspisGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazSvihNastavnika.setBounds(10, 368, 186, 23);
		contentPane.add(btnPrikazSvihNastavnika);
		
	}

}
