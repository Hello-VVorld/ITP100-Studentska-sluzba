package icbl.itp100.studentska_sluzba.ispis.gui;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.CiklusDAO;
import icbl.itp100.studentska_sluzba.dto.CiklusDTO;
import icbl.itp100.studentska_sluzba.table_model.CiklusTableModel;

import javax.swing.JTable;
import javax.swing.JScrollPane;

public class CiklusIspisGUI extends JFrame {
	private static final long serialVersionUID = -6233586625624198527L;
	private JPanel contentPane;
	private JTable table;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CiklusIspisGUI frame = new CiklusIspisGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public CiklusIspisGUI() {
		setType(Type.POPUP);
		setTitle("Prikaz svih ciklusa iz baze");
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		Vector<CiklusDTO> ciklusi = CiklusDAO.getAll();
		List<CiklusDTO> ciklusiKaoLista = new ArrayList<>(ciklusi);

		CiklusTableModel ctm = new CiklusTableModel(ciklusiKaoLista);

		table = new JTable(ctm);
		table.setBounds(10, 11, 414, 240);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 434, 261);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);

	}

}
