package icbl.itp100.studentska_sluzba.ispis.gui;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.OglasDAO;
import icbl.itp100.studentska_sluzba.dto.OglasDTO;
import icbl.itp100.studentska_sluzba.table_model.OglasTableModel;

public class OglasIspisGUI extends JFrame {
	private static final long serialVersionUID = -4471825145987642269L;
	private JPanel contentPane;
	private JTable table;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OglasIspisGUI frame = new OglasIspisGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public OglasIspisGUI() {
		setType(Type.POPUP);
		setTitle("Prikaz svih oglasa iz baze");
		setBounds(100, 100, 633, 429);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		Vector<OglasDTO> oglasi = OglasDAO.getAll();
		List<OglasDTO> oglasiKaoLista = new ArrayList<>(oglasi);

		OglasTableModel otm = new OglasTableModel(oglasiKaoLista);

		table = new JTable(otm);
		table.setBounds(10, 11, 414, 240);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 434, 261);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);

	}

}
