package icbl.itp100.studentska_sluzba.table_model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import icbl.itp100.studentska_sluzba.dto.PredmetDTO;

public class PredmetTableModel extends AbstractTableModel {
	private static final long serialVersionUID = 7811526842127235724L;
	private List<PredmetDTO> predmeti;

	public PredmetTableModel(List<PredmetDTO> predmeti) {
		this.predmeti = predmeti;
	}

	@Override
	public int getRowCount() {
		return predmeti.size();
	}

	@Override
	public int getColumnCount() {
		return 4;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		PredmetDTO predmet = predmeti.get(rowIndex);
		Object value = null;

		switch (columnIndex) {
		case 0:
			value = predmet.getPredmetID();
			break;
		case 1:
			value = predmet.getNazivPredmeta();
			break;
		case 2:
			value = predmet.isObavezan() == true ? "Nije obavezan":"Obavezan";
			break;
		case 3:
			value = predmet.getEcts();
			break;
		}
		
		return value;
	}

	@Override
	public String getColumnName(int column) {
		String name = "??";
		switch (column) {
		case 0:
			name = "ID";
			break;
		case 1:
			name = "Naziv";
			break;
		case 2:
			name = "Obavezan";
			break;
		case 3:
			name = "ECTS";
			break;
		}
		return name;
	}

}
