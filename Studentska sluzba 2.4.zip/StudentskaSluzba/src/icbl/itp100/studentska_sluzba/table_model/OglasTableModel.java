package icbl.itp100.studentska_sluzba.table_model;

import java.util.List;

import javax.swing.table.AbstractTableModel;
import icbl.itp100.studentska_sluzba.dao.OglasnaPlocaDAO;
import icbl.itp100.studentska_sluzba.dto.OglasDTO;
import icbl.itp100.studentska_sluzba.dto.OglasnaPlocaDTO;

public class OglasTableModel extends AbstractTableModel {
	private static final long serialVersionUID = -6585455144444354775L;
	private List<OglasDTO> oglasi;

	public OglasTableModel(List<OglasDTO> oglasi) {
		this.oglasi = oglasi;
	}

	@Override
	public int getRowCount() {
		return oglasi.size();
	}

	@Override
	public int getColumnCount() {
		return 6;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		OglasDTO oglas = oglasi.get(rowIndex);
		Object value = null;

		switch (columnIndex) {
		case 0:
			value = oglas.getOglasID();
			break;
		case 1:
			value = oglas.getNazivOglasa();
			break;
		case 2:
			value = oglas.getSadrzaj();
			break;
		case 3:
			value = oglas.getDatum();
			break;
		case 4:
			value = oglas.isAktivan() == true ? "Aktivan":"Nije aktivan";
			break;
		case 5:
			value = oglas.getOglasnaPlocaFK();
			
			
			OglasnaPlocaDTO opi = new OglasnaPlocaDTO();
			opi = OglasnaPlocaDAO.getByID(oglas.getOglasnaPlocaFK());
			value = opi.getVrstaOglasa();
			break;
		}
		
		return value;
	}

	@Override
	public String getColumnName(int column) {
		String name = "??";
		switch (column) {
		case 0:
			name = "ID";
			break;
		case 1:
			name = "Naziv";
			break;
		case 2:
			name = "Sadrzaj";
			break;
		case 3:
			name = "Datum";
			break;
		case 4:
			name = "Aktivan";
			break;
		case 5:
			name = "Oglasna ploca";
			break;
		}
		return name;
	}
	
}
