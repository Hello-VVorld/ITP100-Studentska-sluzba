package icbl.itp100.studentska_sluzba.unos.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import icbl.itp100.studentska_sluzba.dao.StudentDAO;
import icbl.itp100.studentska_sluzba.dto.StudentDTO;
import icbl.itp100.studentska_sluzba.ispis.gui.StudentIspisGUI;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StudentUnosGUI extends JFrame {
	private static final long serialVersionUID = -6034982586116595108L;
	private JPanel contentPane;
	private JTextField tfIme;
	private JTextField tfPrezime;
	private JTextField tfBrojIndeksa;
	private JTextField tfGodinaUpisa;
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentUnosGUI frame = new StudentUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public StudentUnosGUI() {
		setTitle("Student | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 633, 429);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(408, 21, 207, 21);
		menuBar.setToolTipText("");
		contentPane.add(menuBar);
		JMenu meni = new JMenu("Meni");
		menuBar.add(meni);
		JMenuItem studentMeni = new JMenuItem("Studenti");
		studentMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentUnosGUI sg = new StudentUnosGUI();
				sg.setVisible(true);
			}
		});
		meni.add(studentMeni);
		JMenuItem ciklusMeni = new JMenuItem("Ciklus");
		ciklusMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CiklusUnosGUI cug = new CiklusUnosGUI();
				cug.setVisible(true);
			}
		});
		meni.add(ciklusMeni);
		JMenuItem ispitMeni = new JMenuItem("Ispit");
		ispitMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IspitUnosGUI iug = new IspitUnosGUI();
				iug.setVisible(true);
			}
		});
		meni.add(ispitMeni);
		JMenuItem oglasnaPlocaMeni = new JMenuItem("Oglasna Ploca");
		oglasnaPlocaMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasnaPlocaUnosGUI opg = new OglasnaPlocaUnosGUI();
				opg.setVisible(true);
			}
		});
		meni.add( oglasnaPlocaMeni);
		JMenuItem oglasMeni = new JMenuItem("Oglas");
		oglasMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasUnosGUI og = new OglasUnosGUI();
				og.setVisible(true);
			}
		});
		meni.add(oglasMeni);
		JMenuItem predmetMeni = new JMenuItem("Predmet");
		predmetMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PredmetUnosGUI pg = new PredmetUnosGUI();
				pg.setVisible(true);
			}
		});
		meni.add(predmetMeni);
		JMenuItem studijskiProgramMeni = new JMenuItem("Studijski Program");
		studijskiProgramMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudijskiProgramUnosGUI spg = new StudijskiProgramUnosGUI();
				spg.setVisible(true);
			}
		});
		meni.add(studijskiProgramMeni);
		JMenuItem nastavnikMeni = new JMenuItem("Nastavnik");
		nastavnikMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NastavnikUnosGUI ng = new NastavnikUnosGUI();
				ng.setVisible(true);
			}
		});
		meni.add(nastavnikMeni);
		
		
		JLabel lblIme = new JLabel("Ime:");
		lblIme.setBounds(10, 39, 36, 14);
		contentPane.add(lblIme);
		
		tfIme = new JTextField();
		tfIme.setBounds(10, 64, 300, 20);
		contentPane.add(tfIme);
		tfIme.setColumns(10);
		
		JLabel lblPrezime = new JLabel("Prezime:");
		lblPrezime.setBounds(10, 95, 55, 14);
		contentPane.add(lblPrezime);
		
		tfPrezime = new JTextField();
		tfPrezime.setBounds(10, 120, 300, 20);
		contentPane.add(tfPrezime);
		tfPrezime.setColumns(10);
		
		JLabel lblBrojIndeksa = new JLabel("Broj indeksa:");
		lblBrojIndeksa.setBounds(10, 151, 75, 14);
		contentPane.add(lblBrojIndeksa);
		
		tfBrojIndeksa = new JTextField();
		tfBrojIndeksa.setBounds(10, 176, 86, 20);
		contentPane.add(tfBrojIndeksa);
		tfBrojIndeksa.setColumns(10);
		
		JLabel lblGodinaUpisa = new JLabel("Godina upisa:");
		lblGodinaUpisa.setBounds(10, 207, 86, 14);
		contentPane.add(lblGodinaUpisa);
		
		tfGodinaUpisa = new JTextField();
		tfGodinaUpisa.setBounds(10, 232, 86, 20);
		contentPane.add(tfGodinaUpisa);
		tfGodinaUpisa.setColumns(10);
		
		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String imeStudenta = tfIme.getText();
				String prezimeStudenta = tfPrezime.getText();
				int indeksStudenta = Integer.parseInt(tfBrojIndeksa.getText());
				int upisStudenta = Integer.parseInt(tfGodinaUpisa.getText());
				
				StudentDTO s = new StudentDTO();
				s.setImeStudenta(imeStudenta);
				s.setPrezimeStudenta(prezimeStudenta);
				s.setBrojIndeksa(indeksStudenta);
				s.setGodinaUpisa(upisStudenta);
				boolean uspjesno = StudentDAO.dodajStudent(s);
				String bool = uspjesno ? "Uspjesno ste dodali studenta." : "Dogodila se greska pri dodavanju studenta.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		btnUnesi.setBounds(524, 368, 91, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazSvihStudenata = new JButton("Prikaz svih studenata");
		btnPrikazSvihStudenata.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentIspisGUI prikazSvih=new StudentIspisGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazSvihStudenata.setBounds(10, 368, 186, 23);
		contentPane.add(btnPrikazSvihStudenata);
		
	}
	
}
