package icbl.itp100.studentska_sluzba.unos.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import icbl.itp100.studentska_sluzba.dao.OglasnaPlocaDAO;
import icbl.itp100.studentska_sluzba.dto.OglasnaPlocaDTO;
import icbl.itp100.studentska_sluzba.ispis.gui.OglasnaPlocaIspisGUI;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class OglasnaPlocaUnosGUI extends JFrame {
	private static final long serialVersionUID = -9054563879466090092L;
	private JPanel contentPane;
	private JTextField textField;
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OglasnaPlocaUnosGUI frame = new OglasnaPlocaUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public OglasnaPlocaUnosGUI() {
		setTitle("OglasnaPloca | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 633, 429);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(408, 11, 207, 21);
		menuBar.setToolTipText("");
		contentPane.add(menuBar);
		JMenu meni = new JMenu("Meni");
		menuBar.add(meni);
		JMenuItem studentMeni = new JMenuItem("Studenti");
		studentMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentUnosGUI sg = new StudentUnosGUI();
				sg.setVisible(true);
			}
		});
		meni.add(studentMeni);
		JMenuItem ciklusMeni = new JMenuItem("Ciklus");
		ciklusMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CiklusUnosGUI cug = new CiklusUnosGUI();
				cug.setVisible(true);
			}
		});
		meni.add(ciklusMeni);
		JMenuItem ispitMeni = new JMenuItem("Ispit");
		ispitMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IspitUnosGUI iug = new IspitUnosGUI();
				iug.setVisible(true);
			}
		});
		meni.add(ispitMeni);
		JMenuItem oglasnaPlocaMeni = new JMenuItem("Oglasna Ploca");
		oglasnaPlocaMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasnaPlocaUnosGUI opg = new OglasnaPlocaUnosGUI();
				opg.setVisible(true);
			}
		});
		meni.add( oglasnaPlocaMeni);
		JMenuItem oglasMeni = new JMenuItem("Oglas");
		oglasMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasUnosGUI og = new OglasUnosGUI();
				og.setVisible(true);
			}
		});
		meni.add(oglasMeni);
		JMenuItem predmetMeni = new JMenuItem("Predmet");
		predmetMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PredmetUnosGUI pg = new PredmetUnosGUI();
				pg.setVisible(true);
			}
		});
		meni.add(predmetMeni);
		JMenuItem studijskiProgramMeni = new JMenuItem("Studijski Program");
		studijskiProgramMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudijskiProgramUnosGUI spg = new StudijskiProgramUnosGUI();
				spg.setVisible(true);
			}
		});
		meni.add(studijskiProgramMeni);
		JMenuItem nastavnikMeni = new JMenuItem("Nastavnik");
		nastavnikMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NastavnikUnosGUI ng = new NastavnikUnosGUI();
				ng.setVisible(true);
			}
		});
		meni.add(nastavnikMeni);
		
		
		JLabel lblObavjestenje = new JLabel("Vrsta oglasa:");
		lblObavjestenje.setBounds(10, 35, 91, 14);
		contentPane.add(lblObavjestenje);
		
		textField = new JTextField();
		textField.setBounds(10, 60, 300, 20);
		contentPane.add(textField);
		textField.setColumns(10);

		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String oglas = textField.getText();
				OglasnaPlocaDTO o = new OglasnaPlocaDTO();
				o.setVrstaOglasa(oglas);
				boolean uspjesno = OglasnaPlocaDAO.dodajOglasnaPloca(o);
				String bool = uspjesno ? "Uspjesno ste dodali na oglasnu plocu."
						: "Dogodila se greska pri dodavanju na oglasnu plocu.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		btnUnesi.setBounds(524, 368, 91, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazOglasnePloce = new JButton("Prikaz oglasne ploce");
		btnPrikazOglasnePloce.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OglasnaPlocaIspisGUI prikazSvih=new OglasnaPlocaIspisGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazOglasnePloce.setBounds(10, 368, 186, 23);
		contentPane.add(btnPrikazOglasnePloce);
		


	}
}
