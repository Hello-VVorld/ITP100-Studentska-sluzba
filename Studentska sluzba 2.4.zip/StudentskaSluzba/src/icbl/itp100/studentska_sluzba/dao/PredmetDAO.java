package icbl.itp100.studentska_sluzba.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import icbl.itp100.studentska_sluzba.dto.PredmetDTO;

public class PredmetDAO {

	public static Vector<PredmetDTO> getAll() {
		Vector<PredmetDTO> retVal = new Vector<PredmetDTO>();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM predmet";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();

			while (rs.next())
				retVal.add(new PredmetDTO(rs.getInt(1), rs.getString(2), rs.getBoolean(3), rs.getInt(4)));
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
	}

	public static boolean dodajPredmet(PredmetDTO p) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "INSERT INTO predmet (naziv, obavezan, ects) VALUES (?, ?, ?)";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setString(1, p.getNazivPredmeta());
			boolean status = p.isObavezan();
			if (status)
				ps.setInt(2, 1);
			else
				ps.setInt(2, 0);
			ps.setInt(3, p.getEcts());

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static boolean azurirajPredmet(int predmetID, String nazivPredmeta, boolean obavezan, int ects) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "UPDATE predmet SET naziv = ?, obavezan = ?, ects = ? WHERE id = ?";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setString(1, nazivPredmeta);
			boolean ob = obavezan;
			if (ob)
				ps.setInt(2, 1);
			else
				ps.setInt(2, 2);
			ps.setInt(3, ects);
			ps.setInt(4, predmetID);

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static boolean obrisiPredmet(int predmetID) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "DELETE FROM predmet WHERE id = ?";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, predmetID);

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static PredmetDTO getByID(int predmet) {
		PredmetDTO retVal = new PredmetDTO();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM predmet WHERE id = ?";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, predmet);
			rs = ps.executeQuery();

			while (rs.next()) {
				retVal.setPredmetID(rs.getInt(1));
				retVal.setNazivPredmeta(rs.getString(2));
				retVal.setObavezan(rs.getBoolean(3));
				retVal.setEcts(rs.getInt(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
	}
	
	public static void main(String[] args) {
		System.out.println(PredmetDAO.getAll());
	}

	public static PredmetDTO getByID(int i, PredmetDTO byID) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
