package icbl.itp100.studentska_sluzba.dto;

public class StudentDTO {
	
	int studentID;
	String imeStudenta;
	String prezimeStudenta;
	int brojIndeksa;
	int godinaUpisa;
	
	public StudentDTO(int studentID, String imeStudenta, String prezimeStudenta, int brojIndeksa, int godinaUpisa) {
		super();
		this.studentID = studentID;
		this.imeStudenta = imeStudenta;
		this.prezimeStudenta = prezimeStudenta;
		this.brojIndeksa = brojIndeksa;
		this.godinaUpisa = godinaUpisa;
	}

	public StudentDTO() {
		super();
	}

	public int getStudentID() {
		return studentID;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	public String getImeStudenta() {
		return imeStudenta;
	}

	public void setImeStudenta(String imeStudenta) {
		this.imeStudenta = imeStudenta;
	}

	public String getPrezimeStudenta() {
		return prezimeStudenta;
	}

	public void setPrezimeStudenta(String prezimeStudenta) {
		this.prezimeStudenta = prezimeStudenta;
	}

	public int getBrojIndeksa() {
		return brojIndeksa;
	}

	public void setBrojIndeksa(int brojIndeksa) {
		this.brojIndeksa = brojIndeksa;
	}

	public int getGodinaUpisa() {
		return godinaUpisa;
	}

	public void setGodinaUpisa(int godinaUpisa) {
		this.godinaUpisa = godinaUpisa;
	}
	
	@Override
	public String toString() {
		return studentID + " - " + imeStudenta + " " + prezimeStudenta;
	}
	
}
