package icbl.itp100.studentska_sluzba.ispis.gui;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.NastavnikDAO;
import icbl.itp100.studentska_sluzba.dto.NastavnikDTO;
import icbl.itp100.studentska_sluzba.table_model.NastavnikTableModel;

public class NastavnikIspisGUI extends JFrame {
	private static final long serialVersionUID = 946960352201089237L;
	private JPanel contentPane;
	private JTable table;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NastavnikIspisGUI frame = new NastavnikIspisGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public NastavnikIspisGUI() {
		setType(Type.POPUP);
		setTitle("Prikaz svih nastavnika iz baze");
		setBounds(100, 100, 633, 429);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		Vector<NastavnikDTO> nastavnici = NastavnikDAO.getAll();
		List<NastavnikDTO> nastavniciKaoLista = new ArrayList<>(nastavnici);

		NastavnikTableModel ntm = new NastavnikTableModel(nastavniciKaoLista);

		table = new JTable(ntm);
		table.setBounds(10, 11, 414, 240);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 434, 262);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);

	}

}
