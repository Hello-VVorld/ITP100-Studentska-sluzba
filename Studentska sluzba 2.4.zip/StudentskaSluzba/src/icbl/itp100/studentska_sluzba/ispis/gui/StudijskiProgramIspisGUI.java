package icbl.itp100.studentska_sluzba.ispis.gui;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.StudijskiProgramDAO;
import icbl.itp100.studentska_sluzba.dto.StudijskiProgramDTO;
import icbl.itp100.studentska_sluzba.table_model.StudijskiProgramTableModel;

public class StudijskiProgramIspisGUI extends JFrame {
	private static final long serialVersionUID = -3303189965597927646L;
	private JPanel contentPane;
	private JTable table;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudijskiProgramIspisGUI frame = new StudijskiProgramIspisGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public StudijskiProgramIspisGUI() {
		setType(Type.POPUP);
		setTitle("Prikaz svih studijskih programa iz baze");
		setBounds(100, 100, 633, 429);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		Vector<StudijskiProgramDTO> programi = StudijskiProgramDAO.getAll();
		List<StudijskiProgramDTO> programiKaoLista = new ArrayList<>(programi);

		StudijskiProgramTableModel sptm = new StudijskiProgramTableModel(programiKaoLista);

		table = new JTable(sptm);
		table.setBounds(10, 11, 414, 240);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 434, 261);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);

	}

}
