package icbl.itp100.studentska_sluzba.dto;

public class CiklusDTO {

	int ciklusID;
	String nazivCiklusa;

	public CiklusDTO(int ciklusID, String nazivCiklusa) {
		super();
		this.ciklusID = ciklusID;
		this.nazivCiklusa = nazivCiklusa;
	}

	public CiklusDTO() {
		super();
	}

	public int getCiklusID() {
		return ciklusID;
	}

	public void setCiklusID(int ciklusID) {
		this.ciklusID = ciklusID;
	}

	public String getNazivCiklusa() {
		return nazivCiklusa;
	}

	public void setNazivCiklusa(String nazivCiklusa) {
		this.nazivCiklusa = nazivCiklusa;
	}

	@Override
	public String toString() {
		return ciklusID + " - " + nazivCiklusa;
	}

}
