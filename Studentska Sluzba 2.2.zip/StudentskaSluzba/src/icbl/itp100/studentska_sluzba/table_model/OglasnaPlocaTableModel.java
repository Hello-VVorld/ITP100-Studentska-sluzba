package icbl.itp100.studentska_sluzba.table_model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import icbl.itp100.studentska_sluzba.dto.OglasnaPlocaDTO;

public class OglasnaPlocaTableModel extends AbstractTableModel {
	private static final long serialVersionUID = 7358008814598241826L;
	private List<OglasnaPlocaDTO> ploca;

	public OglasnaPlocaTableModel(List<OglasnaPlocaDTO> ploca) {
		this.ploca = ploca;
	}

	@Override
	public int getRowCount() {
		return ploca.size();
	}

	@Override
	public int getColumnCount() {
		return 2;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		OglasnaPlocaDTO oglasnaPloca = ploca.get(rowIndex);
		Object value = null;

		switch (columnIndex) {
		case 0:
			value = oglasnaPloca.getOglasnaPlocaID();
			break;
		case 1:
			value = oglasnaPloca.getVrstaOglasa();
			break;
		}
		
		return value;
	}

	@Override
	public String getColumnName(int column) {
		String name = "??";
		switch (column) {
		case 0:
			name = "ID";
			break;
		case 1:
			name = "Vrsta oglasa";
			break;
		}
		return name;
	}
	
}
