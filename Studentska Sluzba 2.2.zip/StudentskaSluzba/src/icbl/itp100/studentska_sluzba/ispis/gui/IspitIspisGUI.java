package icbl.itp100.studentska_sluzba.ispis.gui;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.IspitDAO;
import icbl.itp100.studentska_sluzba.dto.IspitDTO;
import icbl.itp100.studentska_sluzba.table_model.IspitTableModel;

public class IspitIspisGUI extends JFrame {
	private static final long serialVersionUID = 4696959155397126493L;
	private JPanel contentPane;
	private JTable table;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IspitIspisGUI frame = new IspitIspisGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public IspitIspisGUI() {
		setType(Type.POPUP);
		setTitle("Prikaz svih ispita iz baze");
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		Vector<IspitDTO> ispiti = IspitDAO.getAll();
		List<IspitDTO> ispitiKaoLista = new ArrayList<>(ispiti);

		IspitTableModel itm = new IspitTableModel(ispitiKaoLista);

		table = new JTable(itm);
		table.setBounds(10, 11, 414, 240);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 434, 261);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);

	}

}
