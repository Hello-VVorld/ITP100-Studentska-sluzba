package icbl.itp100.studentska_sluzba.unos.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dto.CiklusDTO;
import icbl.itp100.studentska_sluzba.ispis.gui.CiklusIspisGUI;
import icbl.itp100.studentska_sluzba.dao.CiklusDAO;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CiklusUnosGUI extends JFrame {
	private static final long serialVersionUID = -3589529765460566331L;
	private JPanel contentPane;
	private JTextField tfNaziv;
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CiklusUnosGUI frame = new CiklusUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public CiklusUnosGUI() {
		setTitle("Ciklus | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(277, 11, 207, 21);
		menuBar.setToolTipText("");
		contentPane.add(menuBar);
		JMenu meni = new JMenu("Meni");
		menuBar.add(meni);
		JMenuItem studentMeni = new JMenuItem("Studenti");
		meni.add(studentMeni);
		JMenuItem ciklusMeni = new JMenuItem("Ciklus");
		meni.add(ciklusMeni);
		JMenuItem ispitMeni = new JMenuItem("Ispit");
		meni.add(ispitMeni);
		JMenuItem oglasnaPlocaMeni = new JMenuItem("Oglasna Ploca");
		meni.add( oglasnaPlocaMeni);
		JMenuItem oglasMeni = new JMenuItem("Oglas");
		meni.add(oglasMeni);
		JMenuItem predmetMeni = new JMenuItem("Predmet");
		meni.add(predmetMeni);
		JMenuItem studijskiProgramMeni = new JMenuItem("Studijski Program");
		meni.add(studijskiProgramMeni);
		JMenuItem nastavnikMeni = new JMenuItem("Nastavnik");
		meni.add(nastavnikMeni);
		
		
		
		JLabel lblNaziv = new JLabel("Naziv:");
		lblNaziv.setBounds(10, 43, 72, 14);
		contentPane.add(lblNaziv);
		
		tfNaziv = new JTextField();
		tfNaziv.setBounds(79, 40, 130, 20);
		contentPane.add(tfNaziv);
		tfNaziv.setColumns(10);
		
		JButton btnUnesi = new JButton("UNOS");
		
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String nazivCiklusa = tfNaziv.getText();
				CiklusDTO c = new CiklusDTO();
				c.setNazivCiklusa(nazivCiklusa);
				boolean uspjesno = CiklusDAO.dodajCiklus(c);
				String bool = uspjesno ? "Uspjesno ste dodali ciklus." : "Dogodila se greska pri dodavanju ciklusa.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		
		btnUnesi.setBounds(333, 226, 91, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazSvihCiklusa = new JButton("Prikaz svih ciklusa");
		btnPrikazSvihCiklusa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CiklusIspisGUI prikazSvih=new CiklusIspisGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazSvihCiklusa.setBounds(10, 226, 186, 23);
		contentPane.add(btnPrikazSvihCiklusa);
		
	}
	
}
