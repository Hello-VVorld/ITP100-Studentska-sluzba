package icbl.itp100.studentska_sluzba.unos.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import icbl.itp100.studentska_sluzba.dao.StudentDAO;
import icbl.itp100.studentska_sluzba.dto.StudentDTO;
import icbl.itp100.studentska_sluzba.ispis.gui.StudentIspisGUI;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StudentUnosGUI extends JFrame {
	private static final long serialVersionUID = -6034982586116595108L;
	private JPanel contentPane;
	private JTextField tfIme;
	private JTextField tfPrezime;
	private JTextField tfBrojIndeksa;
	private JTextField tfGodinaUpisa;
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentUnosGUI frame = new StudentUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public StudentUnosGUI() {
		setTitle("Student | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(277, 11, 207, 21);
		menuBar.setToolTipText("");
		contentPane.add(menuBar);
		JMenu meni = new JMenu("Meni");
		menuBar.add(meni);
		JMenuItem studentMeni = new JMenuItem("Studenti");
		meni.add(studentMeni);
		JMenuItem ciklusMeni = new JMenuItem("Ciklus");
		meni.add(ciklusMeni);
		JMenuItem ispitMeni = new JMenuItem("Ispit");
		meni.add(ispitMeni);
		JMenuItem oglasnaPlocaMeni = new JMenuItem("Oglasna Ploca");
		meni.add( oglasnaPlocaMeni);
		JMenuItem oglasMeni = new JMenuItem("Oglas");
		meni.add(oglasMeni);
		JMenuItem predmetMeni = new JMenuItem("Predmet");
		meni.add(predmetMeni);
		JMenuItem studijskiProgramMeni = new JMenuItem("Studijski Program");
		meni.add(studijskiProgramMeni);
		JMenuItem nastavnikMeni = new JMenuItem("Nastavnik");
		meni.add(nastavnikMeni);
		
		
		JLabel lblIme = new JLabel("Ime:");
		lblIme.setBounds(10, 39, 36, 14);
		contentPane.add(lblIme);
		
		tfIme = new JTextField();
		tfIme.setBounds(36, 36, 142, 20);
		contentPane.add(tfIme);
		tfIme.setColumns(10);
		
		JLabel lblPrezime = new JLabel("Prezime:");
		lblPrezime.setBounds(188, 39, 55, 14);
		contentPane.add(lblPrezime);
		
		tfPrezime = new JTextField();
		tfPrezime.setBounds(253, 36, 171, 20);
		contentPane.add(tfPrezime);
		tfPrezime.setColumns(10);
		
		JLabel lblBrojIndeksa = new JLabel("Broj indeksa:");
		lblBrojIndeksa.setBounds(10, 64, 75, 14);
		contentPane.add(lblBrojIndeksa);
		
		tfBrojIndeksa = new JTextField();
		tfBrojIndeksa.setBounds(10, 80, 86, 20);
		contentPane.add(tfBrojIndeksa);
		tfBrojIndeksa.setColumns(10);
		
		JLabel lblGodinaUpisa = new JLabel("Godina upisa:");
		lblGodinaUpisa.setBounds(10, 104, 86, 14);
		contentPane.add(lblGodinaUpisa);
		
		tfGodinaUpisa = new JTextField();
		tfGodinaUpisa.setBounds(10, 124, 86, 20);
		contentPane.add(tfGodinaUpisa);
		tfGodinaUpisa.setColumns(10);
		
		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String imeStudenta = tfIme.getText();
				String prezimeStudenta = tfPrezime.getText();
				int indeksStudenta = Integer.parseInt(tfBrojIndeksa.getText());
				int upisStudenta = Integer.parseInt(tfGodinaUpisa.getText());
				
				StudentDTO s = new StudentDTO();
				s.setImeStudenta(imeStudenta);
				s.setPrezimeStudenta(prezimeStudenta);
				s.setBrojIndeksa(indeksStudenta);
				s.setGodinaUpisa(upisStudenta);
				boolean uspjesno = StudentDAO.dodajStudent(s);
				String bool = uspjesno ? "Uspjesno ste dodali studenta." : "Dogodila se greska pri dodavanju studenta.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		btnUnesi.setBounds(333, 228, 91, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazSvihStudenata = new JButton("Prikaz svih studenata");
		btnPrikazSvihStudenata.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentIspisGUI prikazSvih=new StudentIspisGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazSvihStudenata.setBounds(10, 228, 186, 23);
		contentPane.add(btnPrikazSvihStudenata);
		
	}
	
}
