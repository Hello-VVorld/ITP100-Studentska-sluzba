package icbl.itp100.studentska_sluzba.unos.gui;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.CiklusDAO;
import icbl.itp100.studentska_sluzba.dao.StudijskiProgramDAO;
import icbl.itp100.studentska_sluzba.dto.CiklusDTO;
import icbl.itp100.studentska_sluzba.dto.StudijskiProgramDTO;
import icbl.itp100.studentska_sluzba.ispis.gui.StudijskiProgramIspisGUI;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Vector;
import java.awt.event.ActionEvent;

public class StudijskiProgramUnosGUI extends JFrame {
	private static final long serialVersionUID = 1172381277062358562L;
	private JPanel contentPane;
	private JTextField tfNaziv;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudijskiProgramUnosGUI frame = new StudijskiProgramUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public StudijskiProgramUnosGUI() {
		setTitle("Studijski program | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(277, 11, 207, 21);
		menuBar.setToolTipText("");
		contentPane.add(menuBar);
		JMenu meni = new JMenu("Meni");
		menuBar.add(meni);
		JMenuItem studentMeni = new JMenuItem("Studenti");
		meni.add(studentMeni);
		JMenuItem ciklusMeni = new JMenuItem("Ciklus");
		meni.add(ciklusMeni);
		JMenuItem ispitMeni = new JMenuItem("Ispit");
		meni.add(ispitMeni);
		JMenuItem oglasnaPlocaMeni = new JMenuItem("Oglasna Ploca");
		meni.add( oglasnaPlocaMeni);
		JMenuItem oglasMeni = new JMenuItem("Oglas");
		meni.add(oglasMeni);
		JMenuItem predmetMeni = new JMenuItem("Predmet");
		meni.add(predmetMeni);
		JMenuItem studijskiProgramMeni = new JMenuItem("Studijski Program");
		meni.add(studijskiProgramMeni);
		JMenuItem nastavnikMeni = new JMenuItem("Nastavnik");
		meni.add(nastavnikMeni);
		
		
		JLabel lblNaziv = new JLabel("Naziv:");
		lblNaziv.setBounds(10, 38, 63, 14);
		contentPane.add(lblNaziv);

		tfNaziv = new JTextField();
		tfNaziv.setBounds(108, 35, 315, 20);
		contentPane.add(tfNaziv);
		tfNaziv.setColumns(10);

		JLabel lblOdaberiCiklus = new JLabel("Odaberi ciklus:");
		lblOdaberiCiklus.setBounds(10, 69, 78, 14);
		contentPane.add(lblOdaberiCiklus);

		Vector<CiklusDTO> sviCiklusi = CiklusDAO.getAll();

		JComboBox cbOdaberiCiklus = new JComboBox(sviCiklusi);
		cbOdaberiCiklus.setBounds(106, 65, 157, 22);
		contentPane.add(cbOdaberiCiklus);

		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String nazivSP = tfNaziv.getText();
				int idCiklus = Integer.parseInt(cbOdaberiCiklus.getSelectedItem().toString().split(" - ")[0]);
				StudijskiProgramDTO studijskiProgramZaUnos = new StudijskiProgramDTO(0, nazivSP, idCiklus);
				boolean uspjesno = StudijskiProgramDAO.dodajStudijskiProgram(studijskiProgramZaUnos);
				String bool = uspjesno ? "Uspjesno ste dodali studijski program."
						: "Dogodila se greska pri dodavanju studijskog programa.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		btnUnesi.setBounds(333, 228, 91, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazSvihStudijskihPrograma = new JButton("Prikaz svih studijskih programa");
		btnPrikazSvihStudijskihPrograma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudijskiProgramIspisGUI prikazSvih=new StudijskiProgramIspisGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazSvihStudijskihPrograma.setBounds(10, 228, 220, 23);
		contentPane.add(btnPrikazSvihStudijskihPrograma);
		
	}
	
}
