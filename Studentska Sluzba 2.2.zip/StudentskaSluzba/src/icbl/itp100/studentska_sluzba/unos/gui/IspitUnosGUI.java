package icbl.itp100.studentska_sluzba.unos.gui;

import java.awt.EventQueue;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.dao.IspitDAO;
import icbl.itp100.studentska_sluzba.dao.NastavnikDAO;
import icbl.itp100.studentska_sluzba.dao.PredmetDAO;
import icbl.itp100.studentska_sluzba.dao.StudentDAO;
import icbl.itp100.studentska_sluzba.dao.StudijskiProgramDAO;
import icbl.itp100.studentska_sluzba.dto.IspitDTO;
import icbl.itp100.studentska_sluzba.dto.NastavnikDTO;
import icbl.itp100.studentska_sluzba.dto.PredmetDTO;
import icbl.itp100.studentska_sluzba.dto.StudentDTO;
import icbl.itp100.studentska_sluzba.dto.StudijskiProgramDTO;
import icbl.itp100.studentska_sluzba.ispis.gui.IspitIspisGUI;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class IspitUnosGUI extends JFrame {
	private static final long serialVersionUID = 5842833164281937877L;
	private JPanel contentPane;
	private JTextField tfOcjena;
	private JTextField tfBrojBodova;
	private JTextField tfDatumIspita;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IspitUnosGUI frame = new IspitUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public IspitUnosGUI() {
		setTitle("Ispit | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(277, 11, 207, 21);
		menuBar.setToolTipText("");
		contentPane.add(menuBar);
		JMenu meni = new JMenu("Meni");
		menuBar.add(meni);
		JMenuItem studentMeni = new JMenuItem("Studenti");
		meni.add(studentMeni);
		JMenuItem ciklusMeni = new JMenuItem("Ciklus");
		meni.add(ciklusMeni);
		JMenuItem ispitMeni = new JMenuItem("Ispit");
		meni.add(ispitMeni);
		JMenuItem oglasnaPlocaMeni = new JMenuItem("Oglasna Ploca");
		meni.add( oglasnaPlocaMeni);
		JMenuItem oglasMeni = new JMenuItem("Oglas");
		meni.add(oglasMeni);
		JMenuItem predmetMeni = new JMenuItem("Predmet");
		meni.add(predmetMeni);
		JMenuItem studijskiProgramMeni = new JMenuItem("Studijski Program");
		meni.add(studijskiProgramMeni);
		JMenuItem nastavnikMeni = new JMenuItem("Nastavnik");
		meni.add(nastavnikMeni);
		
		
		JLabel lblStudent = new JLabel("Student:");
		lblStudent.setBounds(33, 44, 57, 14);
		contentPane.add(lblStudent);
		Vector<StudentDTO> sviStudenti = StudentDAO.getAll();
		JComboBox cbStudent = new JComboBox(sviStudenti);
		cbStudent.setBounds(132, 40, 186, 22);
		contentPane.add(cbStudent);

		JLabel lblPredmet = new JLabel("Predmet:");
		lblPredmet.setBounds(33, 77, 126, 14);
		contentPane.add(lblPredmet);

		Vector<PredmetDTO> sviPredmeti = PredmetDAO.getAll();
		JComboBox cbPredmet = new JComboBox(sviPredmeti);
		cbPredmet.setBounds(132, 73, 186, 22);
		contentPane.add(cbPredmet);

		JLabel lblStudijskiProgram = new JLabel("Studijski program:");
		lblStudijskiProgram.setBounds(33, 106, 89, 14);
		contentPane.add(lblStudijskiProgram);

		Vector<StudijskiProgramDTO> sviSP = StudijskiProgramDAO.getAll();
		JComboBox cbStudijskiProgram = new JComboBox(sviSP);
		cbStudijskiProgram.setBounds(132, 102, 152, 22);
		contentPane.add(cbStudijskiProgram);

		JLabel lblNastavnik = new JLabel("Nastavnik:");
		lblNastavnik.setBounds(33, 137, 82, 14);
		contentPane.add(lblNastavnik);

		Vector<NastavnikDTO> sviNastavnici = NastavnikDAO.getAll();
		JComboBox cbNastavnik = new JComboBox(sviNastavnici);
		cbNastavnik.setBounds(132, 133, 186, 22);
		contentPane.add(cbNastavnik);

		JLabel lblOcjena = new JLabel("Ocjena:");
		lblOcjena.setBounds(33, 162, 82, 14);
		contentPane.add(lblOcjena);

		tfOcjena = new JTextField();
		tfOcjena.setBounds(131, 159, 153, 20);
		contentPane.add(tfOcjena);
		tfOcjena.setColumns(10);

		JLabel lblBrojBodova = new JLabel("Broj bodova:");
		lblBrojBodova.setBounds(33, 193, 126, 14);
		contentPane.add(lblBrojBodova);

		tfBrojBodova = new JTextField();
		tfBrojBodova.setBounds(132, 190, 74, 20);
		contentPane.add(tfBrojBodova);
		tfBrojBodova.setColumns(10);

		JLabel lblDatum = new JLabel("Datum ispita:");
		lblDatum.setBounds(33, 223, 89, 14);
		contentPane.add(lblDatum);

		tfDatumIspita = new JTextField();
		tfDatumIspita.setBounds(132, 220, 152, 20);
		contentPane.add(tfDatumIspita);
		tfDatumIspita.setColumns(10);

		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int studentFK = Integer.parseInt(cbStudent.getSelectedItem().toString().split(" - ")[0]);

				int predmetFK = Integer.parseInt(cbPredmet.getSelectedItem().toString().split(" - ")[0]);

				int studijskiProgramFK = Integer
						.parseInt(cbStudijskiProgram.getSelectedItem().toString().split(" - ")[0]);

				int nastavnikFK = Integer.parseInt(cbNastavnik.getSelectedItem().toString().split(" - ")[0]);

				int ocjena = Integer.parseInt(tfOcjena.getText());

				int bodovi = Integer.parseInt(tfBrojBodova.getText());

				String datum = tfDatumIspita.getText();

				IspitDTO ispitZaUnos = new IspitDTO(0, datum, ocjena, bodovi, studentFK, predmetFK, nastavnikFK,
						studijskiProgramFK);

				boolean uspjesnoDodavanje = IspitDAO.dodajIspit(ispitZaUnos);
				if (uspjesnoDodavanje) {
					JOptionPane.showMessageDialog(null, "Uspjesno te dodali ispit!");
				} else
					JOptionPane.showMessageDialog(null, "Dogodila se greska pri dodavanju ispita!");

			}
		});
		btnUnesi.setBounds(385, 378, 89, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazSvihIspita = new JButton("Prikaz svih ispita");
		btnPrikazSvihIspita.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IspitIspisGUI prikazSvih=new IspitIspisGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazSvihIspita.setBounds(10, 378, 186, 23);
		contentPane.add(btnPrikazSvihIspita);
		
	}

}
