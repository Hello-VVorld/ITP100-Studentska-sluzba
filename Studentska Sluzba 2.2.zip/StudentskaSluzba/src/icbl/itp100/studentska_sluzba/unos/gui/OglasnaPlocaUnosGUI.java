package icbl.itp100.studentska_sluzba.unos.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import icbl.itp100.studentska_sluzba.dao.OglasnaPlocaDAO;
import icbl.itp100.studentska_sluzba.dto.OglasnaPlocaDTO;
import icbl.itp100.studentska_sluzba.ispis.gui.OglasnaPlocaIspisGUI;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class OglasnaPlocaUnosGUI extends JFrame {
	private static final long serialVersionUID = -9054563879466090092L;
	private JPanel contentPane;
	private JTextField textField;
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OglasnaPlocaUnosGUI frame = new OglasnaPlocaUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public OglasnaPlocaUnosGUI() {
		setTitle("OglasnaPloca | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(277, 11, 207, 21);
		menuBar.setToolTipText("");
		contentPane.add(menuBar);
		JMenu meni = new JMenu("Meni");
		menuBar.add(meni);
		JMenuItem studentMeni = new JMenuItem("Studenti");
		meni.add(studentMeni);
		JMenuItem ciklusMeni = new JMenuItem("Ciklus");
		meni.add(ciklusMeni);
		JMenuItem ispitMeni = new JMenuItem("Ispit");
		meni.add(ispitMeni);
		JMenuItem oglasnaPlocaMeni = new JMenuItem("Oglasna Ploca");
		meni.add( oglasnaPlocaMeni);
		JMenuItem oglasMeni = new JMenuItem("Oglas");
		meni.add(oglasMeni);
		JMenuItem predmetMeni = new JMenuItem("Predmet");
		meni.add(predmetMeni);
		JMenuItem studijskiProgramMeni = new JMenuItem("Studijski Program");
		meni.add(studijskiProgramMeni);
		JMenuItem nastavnikMeni = new JMenuItem("Nastavnik");
		meni.add(nastavnikMeni);
		
		
		JLabel lblObavjestenje = new JLabel("Vrsta oglasa:");
		lblObavjestenje.setBounds(10, 46, 91, 14);
		contentPane.add(lblObavjestenje);
		
		textField = new JTextField();
		textField.setBounds(111, 43, 134, 20);
		contentPane.add(textField);
		textField.setColumns(10);

		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String oglas = textField.getText();
				OglasnaPlocaDTO o = new OglasnaPlocaDTO();
				o.setVrstaOglasa(oglas);
				boolean uspjesno = OglasnaPlocaDAO.dodajOglasnaPloca(o);
				String bool = uspjesno ? "Uspjesno ste dodali na oglasnu plocu."
						: "Dogodila se greska pri dodavanju na oglasnu plocu.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		btnUnesi.setBounds(333, 228, 91, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazOglasnePloce = new JButton("Prikaz oglasne ploce");
		btnPrikazOglasnePloce.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OglasnaPlocaIspisGUI prikazSvih=new OglasnaPlocaIspisGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazOglasnePloce.setBounds(10, 228, 186, 23);
		contentPane.add(btnPrikazOglasnePloce);
		


	}
}
