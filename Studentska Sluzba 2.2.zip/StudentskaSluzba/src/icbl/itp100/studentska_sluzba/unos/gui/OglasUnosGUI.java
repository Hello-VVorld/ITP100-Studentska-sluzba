package icbl.itp100.studentska_sluzba.unos.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import icbl.itp100.studentska_sluzba.dao.OglasDAO;
import icbl.itp100.studentska_sluzba.dao.OglasnaPlocaDAO;
import icbl.itp100.studentska_sluzba.dto.OglasDTO;
import icbl.itp100.studentska_sluzba.dto.OglasnaPlocaDTO;
import icbl.itp100.studentska_sluzba.ispis.gui.OglasIspisGUI;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Vector;
import java.awt.event.ActionEvent;

public class OglasUnosGUI extends JFrame {
	private static final long serialVersionUID = -8797379446212868041L;
	private JPanel contentPane;
	private JTextField tfNaziv;
	private JTextField textField;
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OglasUnosGUI frame = new OglasUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public OglasUnosGUI() {
		setTitle("Oglas | Unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(277, 11, 207, 21);
		menuBar.setToolTipText("");
		contentPane.add(menuBar);
		JMenu meni = new JMenu("Meni");
		menuBar.add(meni);
		JMenuItem studentMeni = new JMenuItem("Studenti");
		meni.add(studentMeni);
		JMenuItem ciklusMeni = new JMenuItem("Ciklus");
		meni.add(ciklusMeni);
		JMenuItem ispitMeni = new JMenuItem("Ispit");
		meni.add(ispitMeni);
		JMenuItem oglasnaPlocaMeni = new JMenuItem("Oglasna Ploca");
		meni.add( oglasnaPlocaMeni);
		JMenuItem oglasMeni = new JMenuItem("Oglas");
		meni.add(oglasMeni);
		JMenuItem predmetMeni = new JMenuItem("Predmet");
		meni.add(predmetMeni);
		JMenuItem studijskiProgramMeni = new JMenuItem("Studijski Program");
		meni.add(studijskiProgramMeni);
		JMenuItem nastavnikMeni = new JMenuItem("Nastavnik");
		meni.add(nastavnikMeni);
		

		JLabel lblNaziv = new JLabel("Naziv:");
		lblNaziv.setBounds(10, 39, 53, 14);
		contentPane.add(lblNaziv);

		tfNaziv = new JTextField();
		tfNaziv.setBounds(112, 36, 133, 20);
		contentPane.add(tfNaziv);
		tfNaziv.setColumns(10);

		JLabel lblSadrzaj = new JLabel("Sadrzaj:");
		lblSadrzaj.setBounds(10, 67, 157, 14);
		contentPane.add(lblSadrzaj);

		JTextArea taSadrzaj = new JTextArea();
		taSadrzaj.setBounds(10, 92, 273, 62);
		contentPane.add(taSadrzaj);

		JLabel lblVrstaOglasa = new JLabel("Vrsta oglasa:");
		lblVrstaOglasa.setBounds(10, 165, 157, 14);
		contentPane.add(lblVrstaOglasa);

		Vector<OglasnaPlocaDTO> sviOglasi = OglasnaPlocaDAO.getAll();

		JComboBox cbVrstaOglasa = new JComboBox(sviOglasi);
		cbVrstaOglasa.setBounds(10, 190, 157, 22);
		contentPane.add(cbVrstaOglasa);

		JLabel lblDatum = new JLabel("Datum:");
		lblDatum.setBounds(197, 165, 48, 14);
		contentPane.add(lblDatum);
		
		textField = new JTextField();
		textField.setBounds(187, 191, 96, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"1", "2"}));
		comboBox.setBounds(305, 35, 53, 22);
		contentPane.add(comboBox);
		
		JButton btnUnesi = new JButton("UNOS");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String nazivOglasa = tfNaziv.getText();
				String sadrzaj = taSadrzaj.getText();
				int idOglas = Integer.parseInt(cbVrstaOglasa.getSelectedItem().toString().split(" - ")[0]);
				
				String datum = textField.getText();
				int bol = comboBox.getSelectedIndex();
				boolean status = bol==1 ? false: true;
				
				OglasDTO oglasZaUnos = new OglasDTO(0, nazivOglasa, sadrzaj, datum, status, idOglas);
				boolean uspjesno = OglasDAO.dodajOglas(oglasZaUnos);
				String bool = uspjesno ? "Uspjesno ste dodali oglas!" : "Dogodila se greska pri dodavanju oglasa!";
				JOptionPane.showMessageDialog(null, bool);

			}
		});
		btnUnesi.setBounds(335, 228, 89, 23);
		contentPane.add(btnUnesi);
		
		JButton btnPrikazSvihOglasa = new JButton("Prikaz svih oglasa");
		btnPrikazSvihOglasa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OglasIspisGUI prikazSvih=new OglasIspisGUI();
				prikazSvih.setVisible(true);
			}
		});
		btnPrikazSvihOglasa.setBounds(10, 228, 186, 23);
		contentPane.add(btnPrikazSvihOglasa);
		
		JLabel lblStatus = new JLabel("Status:");
		lblStatus.setBounds(308, 11, 48, 14);
		contentPane.add(lblStatus);
		
		JLabel lblStatus_1 = new JLabel("Status:");
		lblStatus_1.setBounds(255, 39, 46, 14);
		contentPane.add(lblStatus_1);
		

		

		
	}
}
