package icbl.itp100.studentska_sluzba.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import icbl.itp100.studentska_sluzba.dto.OglasnaPlocaDTO;

public class OglasnaPlocaDAO {
	
	public static Vector<OglasnaPlocaDTO> getAll() {
		Vector<OglasnaPlocaDTO> retVal = new Vector<OglasnaPlocaDTO>();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM oglasna_ploca";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();

			while (rs.next())
				retVal.add(new OglasnaPlocaDTO(rs.getInt(1), rs.getString(2)));
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
	}

	public static boolean dodajOglasnaPloca(OglasnaPlocaDTO op) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "INSERT INTO oglasna_ploca (vrsta_oglasa) VALUES (?)";
		
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, op.getOglasnaPlocaID());
			ps.setString(1, op.getVrstaOglasa());
			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static boolean azurirajOglasnaPloca(int oglasnaPlocaID, String vrsta) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "UPDATE oglasna_ploca SET vrsta_oglasa = ? WHERE id = ?";
		
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setString(1, vrsta);
			ps.setInt(2, oglasnaPlocaID);
			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static boolean obrisiOglasnaPloca(int oglasnaPlocaID) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "DELETE FROM oglasna_ploca WHERE id = ?";
		
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, oglasnaPlocaID);

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static OglasnaPlocaDTO getByID(int oglasnaPloca) {
		OglasnaPlocaDTO retVal = new OglasnaPlocaDTO();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM oglasna_ploca WHERE id = ?";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, oglasnaPloca);
			rs = ps.executeQuery();

			while (rs.next()) {
				retVal.setOglasnaPlocaID(rs.getInt(1));
				retVal.setVrstaOglasa(rs.getString(2));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
	}
	
	public static void main(String[] args) {
		System.out.println(OglasnaPlocaDAO.getAll());
	}

}
