package icbl.itp100.studentska_sluzba.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import icbl.itp100.studentska_sluzba.dto.IspitDTO;

public class IspitDAO {
	
	public static Vector<IspitDTO> getAll() {
		Vector<IspitDTO> retVal = new Vector<IspitDTO>();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM ispit";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();

			while (rs.next())
				retVal.add(new IspitDTO(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getInt(5),
						rs.getInt(6), rs.getInt(7), rs.getInt(8)));
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
	}

	public static boolean dodajIspit(IspitDTO i) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "INSERT INTO ispit (datum_ispita, ocjena, broj_bodova, student_fk, predmet_fk,"
				+ "nastavnik_fk, program_fk) VALUES (?, ?, ?, ?, ?, ?, ?)";
		
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setString(1, i.getDatumIspita());
			ps.setInt(2, i.getOcjena());
			ps.setInt(3, i.getBrojBodova());
			ps.setInt(4, i.getStudentFK());
			ps.setInt(5, i.getPredmetFK());
			ps.setInt(6, i.getNastavnikFK());
			ps.setInt(7, i.getStudijskiProgramFK());

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static boolean azurirajIspit(int ispitID, String datumIspita, int ocjena, int brojBodova,
			int studentFK, int predmetFK, int nastavnikFK, int studijskiProgramFK) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "UPDATE ispit SET datum_ispita = ?, ocjena = ?, broj_bodova = ?, student_fk = ?,"
				+ "predmet_fk = ?, nastavnik_fk = ?, program_fk = ? WHERE id = ?";
		
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setString(1, datumIspita);
			ps.setInt(2, ocjena);
			ps.setInt(3, brojBodova);
			ps.setInt(4, studentFK);
			ps.setInt(5, predmetFK);
			ps.setInt(6, nastavnikFK);
			ps.setInt(7, studijskiProgramFK);
			ps.setInt(8, ispitID);

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static boolean obrisiIspit(int ispitID) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "DELETE FROM ispit WHERE id = ?";
		
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, ispitID);

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static IspitDTO getByID(int ispit) {
		IspitDTO retVal = new IspitDTO();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM ispit WHERE id = ?";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, ispit);
			rs = ps.executeQuery();

			while (rs.next()) {
				retVal.setIspitID(rs.getInt(1));
				retVal.setDatumIspita(rs.getString(2));
				retVal.setOcjena(rs.getInt(3));
				retVal.setBrojBodova(rs.getInt(4));
				retVal.setStudentFK(rs.getInt(5));
				retVal.setPredmetFK(rs.getInt(6));
				retVal.setNastavnikFK(rs.getInt(7));
				retVal.setStudijskiProgramFK(rs.getInt(8));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
	}
	
	public static void main(String[] args) {
		System.out.println(IspitDAO.getAll());
	}

}
