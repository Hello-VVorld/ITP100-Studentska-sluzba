package icbl.itp100.studentska_sluzba.ispis.gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import icbl.itp100.studentska_sluzba.azuriranje.CiklusAzuriranjeGUI;
import icbl.itp100.studentska_sluzba.azuriranje.IspitAzuriranjeGUI;
import icbl.itp100.studentska_sluzba.azuriranje.NastavnikAzuriranjeGUI;
import icbl.itp100.studentska_sluzba.azuriranje.OglasAzuriranjeGUI;
import icbl.itp100.studentska_sluzba.azuriranje.OglasnaPlocaAzuriranjeGUI;
import icbl.itp100.studentska_sluzba.azuriranje.PredmetAzuriranjeGUI;
import icbl.itp100.studentska_sluzba.azuriranje.StudentiAzuriranjeGUI;
import icbl.itp100.studentska_sluzba.azuriranje.StudijskiProgramAzuriranjeGUI;
import icbl.itp100.studentska_sluzba.brisanje.CiklusBrisanjeGUI;
import icbl.itp100.studentska_sluzba.brisanje.IspitBrisanjeGUI;
import icbl.itp100.studentska_sluzba.brisanje.NastavnikBrisanjeGUI;
import icbl.itp100.studentska_sluzba.brisanje.OglasBrisanjeGUI;
import icbl.itp100.studentska_sluzba.brisanje.OglasnaPlocaBrisanjeGUI;
import icbl.itp100.studentska_sluzba.brisanje.PredmetBrisanjeGUI;
import icbl.itp100.studentska_sluzba.brisanje.StudentBrisanjeGUI;
import icbl.itp100.studentska_sluzba.brisanje.StudijskiProgramBrisanjeGUI;
import icbl.itp100.studentska_sluzba.dao.IspitDAO;
import icbl.itp100.studentska_sluzba.dto.IspitDTO;
import icbl.itp100.studentska_sluzba.main.gui.MainGUI;
import icbl.itp100.studentska_sluzba.table_model.IspitTableModel;
import icbl.itp100.studentska_sluzba.unos.gui.CiklusUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.IspitUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.NastavnikUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.OglasUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.OglasnaPlocaUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.PredmetUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.StudentUnosGUI;
import icbl.itp100.studentska_sluzba.unos.gui.StudijskiProgramUnosGUI;

public class IspitIspisGUI extends JFrame {
	private static final long serialVersionUID = 4696959155397126493L;
	private JPanel contentPane;
	private JTable table;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IspitIspisGUI frame = new IspitIspisGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public IspitIspisGUI() {
		setType(Type.POPUP);
		setTitle("Ispit | Ispis");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 633, 429);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		/**
		 * Pocetak menija sa cetiri kategodije gdje svaka kategodija ima po osam klasa.
		 */
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(20, 22, 595, 21);
		menuBar.setToolTipText("");
		contentPane.add(menuBar);
		
		JMenu pocetna = new JMenu("ITP100");
		menuBar.add(pocetna);
		JMenuItem pocetnaMeni = new JMenuItem("Pocetna");
		pocetnaMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainGUI pm = new MainGUI();
				pm.setVisible(true);
			}
		});
		pocetna.add(pocetnaMeni);
		
		JMenu meni = new JMenu("Dodaj");
		menuBar.add(meni);
		JMenuItem studentMeni = new JMenuItem("Studenti");
		studentMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentUnosGUI sg = new StudentUnosGUI();
				sg.setVisible(true);
			}
		});
		meni.add(studentMeni);
		JMenuItem ciklusMeni = new JMenuItem("Ciklus");
		ciklusMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CiklusUnosGUI cug = new CiklusUnosGUI();
				cug.setVisible(true);
			}
		});
		meni.add(ciklusMeni);
		JMenuItem ispitMeni = new JMenuItem("Ispit");
		ispitMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IspitUnosGUI iug = new IspitUnosGUI();
				iug.setVisible(true);
			}
		});
		meni.add(ispitMeni);
		JMenuItem oglasnaPlocaMeni = new JMenuItem("Oglasna ploca");
		oglasnaPlocaMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasnaPlocaUnosGUI opg = new OglasnaPlocaUnosGUI();
				opg.setVisible(true);
			}
		});
		meni.add( oglasnaPlocaMeni);
		JMenuItem oglasMeni = new JMenuItem("Oglas");
		oglasMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasUnosGUI og = new OglasUnosGUI();
				og.setVisible(true);
			}
		});
		meni.add(oglasMeni);
		JMenuItem predmetMeni = new JMenuItem("Predmet");
		predmetMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PredmetUnosGUI pg = new PredmetUnosGUI();
				pg.setVisible(true);
			}
		});
		meni.add(predmetMeni);
		JMenuItem studijskiProgramMeni = new JMenuItem("Studijski program");
		studijskiProgramMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudijskiProgramUnosGUI spg = new StudijskiProgramUnosGUI();
				spg.setVisible(true);
			}
		});
		meni.add(studijskiProgramMeni);
		JMenuItem nastavnikMeni = new JMenuItem("Nastavnik");
		nastavnikMeni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NastavnikUnosGUI ng = new NastavnikUnosGUI();
				ng.setVisible(true);
			}
		});
		meni.add(nastavnikMeni);
		
		JMenu meniTable = new JMenu("Ispis tabela");
		menuBar.add(meniTable );
		JMenuItem studentMeniIspis = new JMenuItem("Studenti");
		studentMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentIspisGUI sgi = new StudentIspisGUI();
				sgi.setVisible(true);
			}
		});
		meniTable.add(studentMeniIspis);
		JMenuItem ciklusMeniIspis = new JMenuItem("Ciklus");
		ciklusMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CiklusIspisGUI cgi = new CiklusIspisGUI();
				cgi.setVisible(true);
			}
		});
		meniTable.add(ciklusMeniIspis);
		JMenuItem ispitMeniIspis = new JMenuItem("Ispit");
		ispitMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IspitIspisGUI igi = new IspitIspisGUI();
				igi.setVisible(true);
			}
		});
		meniTable.add(ispitMeniIspis);
		JMenuItem oglasnaPlocaMeniIspis = new JMenuItem("Oglasna ploca");
		oglasnaPlocaMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasnaPlocaIspisGUI opgi = new OglasnaPlocaIspisGUI();
				opgi.setVisible(true);
			}
		});
		meniTable.add(oglasnaPlocaMeniIspis);
		JMenuItem oglasMeniIspis = new JMenuItem("Oglas");
		oglasMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasIspisGUI ogio = new OglasIspisGUI();
				ogio.setVisible(true);
			}
		});
		meniTable.add(oglasMeniIspis);
		JMenuItem predmetMeniIspis = new JMenuItem("Predmet");
		predmetMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PredmetIspisGUI pgi = new PredmetIspisGUI();
				pgi.setVisible(true);
			}
		});
		meniTable.add(predmetMeniIspis);
		JMenuItem studijskiProgramMeniIspis = new JMenuItem("Studijski program");
		studijskiProgramMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudijskiProgramIspisGUI spgi = new StudijskiProgramIspisGUI();
				spgi.setVisible(true);
			}
		});
		meniTable.add(studijskiProgramMeniIspis);
		JMenuItem nastavnikMeniIspis = new JMenuItem("Nastavnik");
		nastavnikMeniIspis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NastavnikIspisGUI ngi = new NastavnikIspisGUI();
				ngi.setVisible(true);
			}
		});
		meniTable.add(nastavnikMeniIspis);
		
		JMenu meniBrisanje = new JMenu("Brisanje podataka");
		menuBar.add(meniBrisanje);
		JMenuItem studentMeniBrisanje = new JMenuItem("Student");
		studentMeniBrisanje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentBrisanjeGUI sgb = new StudentBrisanjeGUI();
				sgb.setVisible(true);
			}
		});
		meniBrisanje.add(studentMeniBrisanje);
		JMenuItem ciklusMeniBrisanje = new JMenuItem("Ciklus");
		ciklusMeniBrisanje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CiklusBrisanjeGUI cgb = new CiklusBrisanjeGUI();
				cgb.setVisible(true);
			}
		});
		meniBrisanje.add(ciklusMeniBrisanje);
		JMenuItem ispitMeniBrisanje = new JMenuItem("Ispit");
		ispitMeniBrisanje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IspitBrisanjeGUI igi = new IspitBrisanjeGUI();
				igi.setVisible(true);
			}
		});
		meniBrisanje.add(ispitMeniBrisanje);
		JMenuItem oglasnaPlocaMeniBrisanje = new JMenuItem("Oglasna ploca");
		oglasnaPlocaMeniBrisanje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasnaPlocaBrisanjeGUI opgb = new OglasnaPlocaBrisanjeGUI();
				opgb.setVisible(true);
			}
		});
		meniBrisanje.add(oglasnaPlocaMeniBrisanje);
		JMenuItem oglasMeniBrisanje = new JMenuItem("Oglas");
		oglasMeniBrisanje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasBrisanjeGUI ogib = new OglasBrisanjeGUI();
				ogib.setVisible(true);
			}
		});
		meniBrisanje.add(oglasMeniBrisanje);
		JMenuItem predmetMeniBrisanje = new JMenuItem("Predmet");
		predmetMeniBrisanje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PredmetBrisanjeGUI pgb = new PredmetBrisanjeGUI();
				pgb.setVisible(true);
			}
		});
		meniBrisanje.add(predmetMeniBrisanje);
		JMenuItem studijskiProgramMeniBrisanje= new JMenuItem("Studijski program");
		studijskiProgramMeniBrisanje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudijskiProgramBrisanjeGUI spgb = new StudijskiProgramBrisanjeGUI();
				spgb.setVisible(true);
			}
		});
		meniBrisanje.add(studijskiProgramMeniBrisanje);
		JMenuItem nastavnikMeniBrisanje = new JMenuItem("Nastavnik");
		nastavnikMeniBrisanje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NastavnikBrisanjeGUI ngb = new NastavnikBrisanjeGUI();
				ngb.setVisible(true);
			}
		});
		meniBrisanje.add(nastavnikMeniBrisanje);
		
		JMenu meniAzuriranje = new JMenu("Azuriranje podataka");
		menuBar.add(meniAzuriranje);
		JMenuItem studentMeniAzuriranje = new JMenuItem("Student");
		studentMeniAzuriranje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentiAzuriranjeGUI sga = new StudentiAzuriranjeGUI();
				sga.setVisible(true);
			}
		});
		meniAzuriranje.add(studentMeniAzuriranje);
		JMenuItem ciklusMeniAzuriranje = new JMenuItem("Ciklus");
		ciklusMeniAzuriranje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CiklusAzuriranjeGUI cga = new CiklusAzuriranjeGUI();
				cga.setVisible(true);
			}
		});
		meniAzuriranje.add(ciklusMeniAzuriranje);
		JMenuItem ispitMeniAzuriranje = new JMenuItem("Ispit");
		ispitMeniAzuriranje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IspitAzuriranjeGUI iga = new IspitAzuriranjeGUI();
				iga.setVisible(true);
			}
		});
		meniAzuriranje.add(ispitMeniAzuriranje);
		JMenuItem oglasnaPlocaMeniAzuriranje = new JMenuItem("Oglasna ploca");
		oglasnaPlocaMeniAzuriranje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasnaPlocaAzuriranjeGUI opga = new OglasnaPlocaAzuriranjeGUI();
				opga.setVisible(true);
			}
		});
		meniAzuriranje.add(oglasnaPlocaMeniAzuriranje);
		JMenuItem oglasMeniAzuriranje = new JMenuItem("Oglas");
		oglasMeniAzuriranje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OglasAzuriranjeGUI ogia = new OglasAzuriranjeGUI();
				ogia.setVisible(true);
			}
		});
		meniAzuriranje.add(oglasMeniAzuriranje);
		JMenuItem predmetMeniAzuriranje = new JMenuItem("Predmet");
		predmetMeniAzuriranje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PredmetAzuriranjeGUI pga = new PredmetAzuriranjeGUI();
				pga.setVisible(true);
			}
		});
		meniAzuriranje.add(predmetMeniAzuriranje);
		JMenuItem studijskiProgramMeniAzuriranje = new JMenuItem("Studijski program");
		studijskiProgramMeniAzuriranje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudijskiProgramAzuriranjeGUI spga = new StudijskiProgramAzuriranjeGUI();
				spga.setVisible(true);
			}
		});
		meniAzuriranje.add(studijskiProgramMeniAzuriranje);
		JMenuItem nastavnikMeniAzuriranje = new JMenuItem("Nastavnik");
		nastavnikMeniAzuriranje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NastavnikAzuriranjeGUI nga = new NastavnikAzuriranjeGUI();
				nga.setVisible(true);
			}
		});
		meniAzuriranje.add(nastavnikMeniAzuriranje);
		/**
		 * Kraj menija sa cetiri kategodije gdje svaka kategodija ima po osam klasa.
		 */

		Vector<IspitDTO> ispiti = IspitDAO.getAll();
		List<IspitDTO> ispitiKaoLista = new ArrayList<>(ispiti);

		IspitTableModel itm = new IspitTableModel(ispitiKaoLista);

		table = new JTable(itm);
		table.setBounds(10, 11, 414, 240);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 60, 605, 331);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);

	}

}
