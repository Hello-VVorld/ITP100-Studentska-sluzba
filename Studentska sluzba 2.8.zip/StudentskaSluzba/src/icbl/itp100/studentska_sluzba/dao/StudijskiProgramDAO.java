package icbl.itp100.studentska_sluzba.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import icbl.itp100.studentska_sluzba.dto.StudijskiProgramDTO;

public class StudijskiProgramDAO {

	public static Vector<StudijskiProgramDTO> getAll() {
		Vector<StudijskiProgramDTO> retVal = new Vector<StudijskiProgramDTO>();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM studijski_program";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();

			while (rs.next())
				retVal.add(new StudijskiProgramDTO(rs.getInt(1), rs.getString(2), rs.getInt(3)));
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
	}

	public static boolean dodajStudijskiProgram(StudijskiProgramDTO sp) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "INSERT INTO studijski_program (naziv, ciklus_fk) VALUES (?, ?)";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setString(1, sp.getNazivSP());
			ps.setInt(2, sp.getCiklusFK());

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static boolean azurirajStudijskiProgram(int studijskiProgramID, String nazivSP, int ciklusFK) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "UPDATE studijski_program SET naziv = ?, ciklus_fk = ? WHERE id = ?";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setString(1, nazivSP);
			ps.setInt(2, ciklusFK);
			ps.setInt(3, studijskiProgramID);
			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static boolean obrisiStudijskiProgram(int studijskiProgramID) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "DELETE FROM studijski_program WHERE id = ?";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, studijskiProgramID);

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static StudijskiProgramDTO getByID(int studijskiProgram) {
		StudijskiProgramDTO retVal = new StudijskiProgramDTO();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM studijski_program WHERE id = ?";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, studijskiProgram);
			rs = ps.executeQuery();

			while (rs.next()) {
				retVal.setStudijskiProgramID(rs.getInt(1));
				retVal.setNazivSP(rs.getString(2));
				retVal.setCiklusFK(rs.getInt(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
	}
	
	public static void main(String[] args) {
		System.out.println(StudijskiProgramDAO.getAll());
	}

}
