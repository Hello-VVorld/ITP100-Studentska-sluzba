-- phpMyAdmin SQL Dump
-- version 4.0.4.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 23, 2019 at 12:45 PM
-- Server version: 5.6.13
-- PHP Version: 5.4.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `baza_studentske_sluzbe`
--
CREATE DATABASE IF NOT EXISTS `baza_studentske_sluzbe` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `baza_studentske_sluzbe`;

-- --------------------------------------------------------

--
-- Table structure for table `ciklus`
--

CREATE TABLE IF NOT EXISTS `ciklus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(45) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ispit`
--

CREATE TABLE IF NOT EXISTS `ispit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum_ispita` varchar(45) COLLATE utf8_bin NOT NULL,
  `ocjena` int(11) NOT NULL,
  `broj_bodova` int(11) NOT NULL,
  `student_fk` int(11) NOT NULL,
  `predmet_fk` int(11) NOT NULL,
  `nastavnik_fk` int(11) NOT NULL,
  `program_fk` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ispit_student_idx` (`student_fk`),
  KEY `fk_ispit_predmet1_idx` (`predmet_fk`),
  KEY `fk_ispit_nastavnik1_idx` (`nastavnik_fk`),
  KEY `fk_ispit_program1_idx` (`program_fk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nastavnik`
--

CREATE TABLE IF NOT EXISTS `nastavnik` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(45) COLLATE utf8_bin NOT NULL,
  `prezime` varchar(45) COLLATE utf8_bin NOT NULL,
  `zvanje` varchar(45) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `oglas`
--

CREATE TABLE IF NOT EXISTS `oglas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(45) COLLATE utf8_bin NOT NULL,
  `sadrzaj` varchar(500) COLLATE utf8_bin NOT NULL,
  `datum` varchar(45) COLLATE utf8_bin NOT NULL,
  `aktivan` tinyint(4) NOT NULL,
  `oglasna_ploca_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_oglas_ploca1_idx` (`oglasna_ploca_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `oglasna_ploca`
--

CREATE TABLE IF NOT EXISTS `oglasna_ploca` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vrsta_oglasa` varchar(45) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `predmet`
--

CREATE TABLE IF NOT EXISTS `predmet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) COLLATE utf8_bin NOT NULL,
  `obavezan` tinyint(4) NOT NULL,
  `ects` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(45) COLLATE utf8_bin NOT NULL,
  `prezime` varchar(45) COLLATE utf8_bin NOT NULL,
  `broj_indeksa` int(11) NOT NULL,
  `godina_upisa` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `studijski_program`
--

CREATE TABLE IF NOT EXISTS `studijski_program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(45) COLLATE utf8_bin NOT NULL,
  `ciklus_fk` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_program_ciklus1_idx` (`ciklus_fk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ispit`
--
ALTER TABLE `ispit`
  ADD CONSTRAINT `fk_ispit_nastavnik1` FOREIGN KEY (`nastavnik_fk`) REFERENCES `nastavnik` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_ispit_predmet1` FOREIGN KEY (`predmet_fk`) REFERENCES `predmet` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_ispit_program1` FOREIGN KEY (`program_fk`) REFERENCES `studijski_program` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_ispit_student` FOREIGN KEY (`student_fk`) REFERENCES `student` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `oglas`
--
ALTER TABLE `oglas`
  ADD CONSTRAINT `fk_oglas_ploca1` FOREIGN KEY (`oglasna_ploca_id`) REFERENCES `oglasna_ploca` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `studijski_program`
--
ALTER TABLE `studijski_program`
  ADD CONSTRAINT `fk_program_ciklus1` FOREIGN KEY (`ciklus_fk`) REFERENCES `ciklus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
