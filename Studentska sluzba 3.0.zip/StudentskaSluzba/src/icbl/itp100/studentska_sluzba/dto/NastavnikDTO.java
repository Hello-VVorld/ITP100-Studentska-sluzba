package icbl.itp100.studentska_sluzba.dto;

public class NastavnikDTO {

	int nastavnikID;
	String imeNastavnika;
	String prezimeNastavnika;
	String zvanje;

	public NastavnikDTO(int nastavnikID, String imeNastavnika, String prezimeNastavnika, String zvanje) {
		super();
		this.nastavnikID = nastavnikID;
		this.imeNastavnika = imeNastavnika;
		this.prezimeNastavnika = prezimeNastavnika;
		this.zvanje = zvanje;
	}

	public NastavnikDTO() {
		super();
	}

	public int getNastavnikID() {
		return nastavnikID;
	}

	public void setNastavnikID(int nastavnikID) {
		this.nastavnikID = nastavnikID;
	}

	public String getImeNastavnika() {
		return imeNastavnika;
	}

	public void setImeNastavnika(String imeNastavnika) {
		this.imeNastavnika = imeNastavnika;
	}

	public String getPrezimeNastavnika() {
		return prezimeNastavnika;
	}

	public void setPrezimeNastavnika(String prezimeNastavnika) {
		this.prezimeNastavnika = prezimeNastavnika;
	}

	public String getZvanje() {
		return zvanje;
	}

	public void setZvanje(String zvanje) {
		this.zvanje = zvanje;
	}
	
	@Override
	public String toString() {
		return nastavnikID + " - " + imeNastavnika + " " + prezimeNastavnika;
	}

}
