package icbl.itp100.studentska_sluzba.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import icbl.itp100.studentska_sluzba.dto.OglasDTO;

public class OglasDAO {
	
	public static Vector<OglasDTO> getAll() {
		Vector<OglasDTO> retVal = new Vector<OglasDTO>();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM oglas ORDER BY id DESC";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();

			while (rs.next())
				retVal.add(new OglasDTO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getBoolean(5), rs.getInt(6)));
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
	}

	public static boolean dodajOglas(OglasDTO o) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "INSERT INTO oglas (naziv, sadrzaj, datum, aktivan, oglasna_ploca_id)"
				+ "VALUES (?, ?, ?, ?, ?)";
		
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setString(1, o.getNazivOglasa());
			ps.setString(2, o.getSadrzaj());
			ps.setString(3, o.getDatum());
			boolean ak = o.isAktivan();
			if (ak)
				ps.setInt(4, 1);
			else
				ps.setInt(4, 0);
			ps.setInt(5, o.getOglasnaPlocaFK());

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static boolean azurirajOglas(int oglasID, String nazivOglasa, String sadrzaj,
			String datum, boolean aktivan, int oglasnaPlocaFK) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "UPDATE oglas SET naziv=?, sadrzaj = ?, datum = ?, aktivan = ?,"
				+ "oglasna_ploca_id = ? WHERE id = ?";
		
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setString(1, nazivOglasa);
			ps.setString(2, sadrzaj);
			ps.setString(3, datum);
			boolean status = aktivan;
			if (status)
				ps.setInt(4, 1);
			else
				ps.setInt(4, 0);
			ps.setInt(5, oglasnaPlocaFK);
			ps.setInt(6, oglasID);

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static boolean obrisiOglas(int oglasID) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "DELETE FROM oglas WHERE id = ?";
		
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, oglasID);

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}

	public static OglasDTO getByID(int oglas) {
		OglasDTO retVal = new OglasDTO();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM oglas WHERE id = ?";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, oglas);
			rs = ps.executeQuery();

			while (rs.next()) {
				retVal.setOglasID(rs.getInt(1));
				retVal.setNazivOglasa(rs.getString(2));
				retVal.setSadrzaj(rs.getString(3));
				retVal.setDatum(rs.getString(4));
				retVal.setAktivan(rs.getBoolean(5));
				retVal.setOglasnaPlocaFK(rs.getInt(6));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
	}
	
	public static void main(String[] args) {
		System.out.println(OglasDAO.getAll());
	}

}
