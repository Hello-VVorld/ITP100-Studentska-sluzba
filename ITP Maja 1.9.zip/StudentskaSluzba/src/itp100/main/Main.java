package itp100.main;

import java.sql.SQLException;
import java.util.Scanner;
import java.util.Vector;

import itp100.DAO.CiklusDAO;
import itp100.DAO.NastavnikDAO;
import itp100.DAO.StudijskiProgramDAO;
import itp100.DTO.CiklusDTO;
import itp100.DTO.NastavnikDTO;
import itp100.DTO.StudijskiProgramDTO;



public class Main {

	public static void main(String[] args) throws SQLException {
		// Prikaz svih ciklusa
		Vector<CiklusDTO> ciklusi = CiklusDAO.getAll();
		System.out.println("u bazi je "+ ciklusi.size() + " ciklusa.");
		System.out.println("Spisak ciklusa: ");
		for (CiklusDTO c : ciklusi) {
			System.out.println(c.getNaziv());
		}
		Vector<StudijskiProgramDTO> sp = StudijskiProgramDAO.getAll();
		System.out.println("u bazi je "+ sp.size() + " studijski program.");
		System.out.println("Spisak studijskog programa: ");
		for (StudijskiProgramDTO s : sp) {
			System.out.println(s.getNaziv() +" sa studijskog programa "+ s.getCiklus());
		}
		Vector<NastavnikDTO> nastavnici = NastavnikDAO.getAll();
		System.out.println("u bazi je "+ nastavnici.size() + " nastavnik.");
		System.out.println("Spisak nastavnika: ");
		for (NastavnikDTO nas : nastavnici) {
			System.out.println(nas.getId());
		
		
		// Dodavanje novog ciklusa
		Scanner sc = new Scanner(System.in);
		CiklusDTO c = new CiklusDTO();
		System.out.println("*** DODAVANJE NOVOG CIKLUSA ***");
		System.out.println("Unesite naziv: ");
		c.setNaziv(sc.nextLine());
		
		boolean uspjesno = CiklusDAO.dodajCiklus(c);
		if (uspjesno) {
			System.out.println("Uspjesno ste dodali ciklus.");
		} else {
			System.out.println("Dogodila se greska pri dodavanju ciklusa.");
		}
		
}
	}
}


