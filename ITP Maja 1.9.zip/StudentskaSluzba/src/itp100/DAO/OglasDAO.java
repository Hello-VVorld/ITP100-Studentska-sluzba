package itp100.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import itp100.DTO.OglasDTO;

public class OglasDAO {

	public static Vector<OglasDTO> getAll() {
		Vector<OglasDTO> retVal = new Vector<OglasDTO>();
		Connection conn = null;
		java.sql.PreparedStatement ps = null;
		ResultSet rs = null;

		String query = "SELECT * FROM oglas ";

		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();

			while (rs.next())
				retVal.add(new OglasDTO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getBoolean(5), rs.getInt(6)));
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps, rs);
		}
		return retVal;
}
	public static boolean dodajOglas(OglasDTO o) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "INSERT INTO oglas (Id, naziv, sadrzaj, datum, aktivan, oglasna_ploca) VALUES (?, ?, ?, ?, ?, ?)";
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, o.getId());
			ps.setString(2, o.getNaziv());
			ps.setString(3,  o.getSadrzaj());
			ps.setInt(4, o.getDatum());
			ps.setBoolean(5, o.isAktivan());
			ps.setInt(6, o.getOglasnaPloca());
			

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}
	public static boolean azurirajOglas(int Id, String naziv, String  sadrzaj, int datum, boolean aktivan, String oglasnaPloca) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "UPDATE oglas SET nazivOglasa=? WHERE id_oglasa=?";
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, Id);
			ps.setString(2, naziv);
			ps.setString(3, sadrzaj);
			ps.setInt(4, datum);
			ps.setBoolean(5, aktivan);
			ps.setString(6, oglasnaPloca);
			
			
			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}
	public static boolean obrisiOglas(int Id) {
		boolean retVal = false;
		Connection conn = null;
		java.sql.PreparedStatement ps = null;

		String query = "DELETE FROM oglas WHERE id_oglasa=?";
		try {
			conn = ConnectionPool.getInstance().checkOut();
			ps = conn.prepareStatement(query);
			ps.setInt(1, Id);

			retVal = ps.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtilities.getInstance().showSQLException(e);
		} finally {
			ConnectionPool.getInstance().checkIn(conn);
			DBUtilities.getInstance().close(ps);
		}
		return retVal;
	}
	
		public static OglasDTO getById(int o) {
			OglasDTO retVal = new OglasDTO();
			Connection conn = null;
			java.sql.PreparedStatement ps = null;
			ResultSet rs = null;

			String query = "SELECT * FROM oglas WHERE id_oglas=? ";

			try {
				conn = ConnectionPool.getInstance().checkOut();
				ps = conn.prepareStatement(query);
				rs = ps.executeQuery();

				while (rs.next()) {
					retVal.setId(rs.getInt(1));
					retVal.setNaziv(rs.getString(2));
					retVal.setSadrzaj(rs.getString(3));
					retVal.setDatum(rs.getInt(4));
					retVal.setAktivan(rs.getBoolean(5));
					retVal.setOglasnaPloca(rs.getInt(6));
					
					
				}
			} catch (SQLException e) {
				e.printStackTrace();
				DBUtilities.getInstance().showSQLException(e);
			} finally {
				ConnectionPool.getInstance().checkIn(conn);
				DBUtilities.getInstance().close(ps, rs);
			}
			return retVal;
	
	
}
}

