package itp100.DTO;

public class StudijskiProgramDTO {

	int Id;
	String naziv;
	int ciklus;
	
	public StudijskiProgramDTO(int id, String naziv, int ciklus) {
		super();
		Id = id;
		this.naziv = naziv;
		this.ciklus = ciklus;
	}

	public StudijskiProgramDTO() {
		super();
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public int getCiklus() {
		return ciklus;
	}

	public void setCiklus(int ciklus) {
		this.ciklus = ciklus;
	}

	@Override
	public String toString() {
		return Id+"-" +naziv;
	}
	
	
}
	
	