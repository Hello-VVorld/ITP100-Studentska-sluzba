package itp100.DTO;

public class OglasDTO {

	int Id;
	String naziv;
	String sadrzaj;
	int datum;
	boolean aktivan;
	int OglasnaPloca;
	public OglasDTO(int id, String naziv, String sadrzaj, int datum, boolean aktivan, int oglasnaPloca) {
		super();
		Id = id;
		this.naziv = naziv;
		this.sadrzaj = sadrzaj;
		this.datum = datum;
		this.aktivan = aktivan;
		OglasnaPloca = oglasnaPloca;
	}
	public OglasDTO() {
		super();
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getNaziv() {
		return naziv;
	}
	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}
	public String getSadrzaj() {
		return sadrzaj;
	}
	public void setSadrzaj(String sadrzaj) {
		this.sadrzaj = sadrzaj;
	}
	public int getDatum() {
		return datum;
	}
	public void setDatum(int datum) {
		this.datum = datum;
	}
	public boolean isAktivan() {
		return aktivan;
	}
	public void setAktivan(boolean aktivan) {
		this.aktivan = aktivan;
	}
	public int getOglasnaPloca() {
		return OglasnaPloca;
	}
	public void setOglasnaPloca(int oglasnaPloca) {
		OglasnaPloca = oglasnaPloca;
	}
	@Override
	public String toString() {
		return "OglasDTO [Id=" + Id + ", naziv=" + naziv + ", sadrzaj=" + sadrzaj + ", datum=" + datum + ", aktivan="
				+ aktivan + ", OglasnaPloca=" + OglasnaPloca + "]";
	}
	
	
	
}
