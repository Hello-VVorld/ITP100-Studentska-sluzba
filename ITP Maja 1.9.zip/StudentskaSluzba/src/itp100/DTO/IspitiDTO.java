package itp100.DTO;

public class IspitiDTO {
	
	int Id;
	String datum;
	int ocjena;
	int brojBodova;
	int IdNastavnik;
	int IdPredmet;
	int IdStudenti;
	int IdStudijskiProgram;
	public IspitiDTO(int id, String datum, int ocjena, int brojBodova, int idNastavnik, int idPredmet, int idStudenti,
			int idStudijskiProgram) {
		super();
		Id = id;
		this.datum = datum;
		this.ocjena = ocjena;
		this.brojBodova = brojBodova;
		IdNastavnik = idNastavnik;
		IdPredmet = idPredmet;
		IdStudenti = idStudenti;
		IdStudijskiProgram = idStudijskiProgram;
	}
	public IspitiDTO() {
		super();
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getDatum() {
		return datum;
	}
	public void setDatum(String datum) {
		this.datum = datum;
	}
	public int getOcjena() {
		return ocjena;
	}
	public void setOcjena(int ocjena) {
		this.ocjena = ocjena;
	}
	public int getBrojBodova() {
		return brojBodova;
	}
	public void setBrojBodova(int brojBodova) {
		this.brojBodova = brojBodova;
	}
	public int getIdNastavnik() {
		return IdNastavnik;
	}
	public void setIdNastavnik(int idNastavnik) {
		IdNastavnik = idNastavnik;
	}
	public int getIdPredmet() {
		return IdPredmet;
	}
	public void setIdPredmet(int idPredmet) {
		IdPredmet = idPredmet;
	}
	public int getIdStudenti() {
		return IdStudenti;
	}
	public void setIdStudenti(int idStudenti) {
		IdStudenti = idStudenti;
	}
	public int getIdStudijskiProgram() {
		return IdStudijskiProgram;
	}
	public void setIdStudijskiProgram(int idStudijskiProgram) {
		IdStudijskiProgram = idStudijskiProgram;
	}
	@Override
	public String toString() {
		return "IspitiDTO [Id=" + Id + ", datum=" + datum + ", ocjena=" + ocjena + ", brojBodova=" + brojBodova
				+ ", IdNastavnik=" + IdNastavnik + ", IdPredmet=" + IdPredmet + ", IdStudenti=" + IdStudenti
				+ ", IdStudijskiProgram=" + IdStudijskiProgram + "]";
	}

	
	
	
}

	
