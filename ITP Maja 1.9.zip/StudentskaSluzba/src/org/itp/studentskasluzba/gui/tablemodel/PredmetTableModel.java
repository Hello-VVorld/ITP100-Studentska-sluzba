package org.itp.studentskasluzba.gui.tablemodel;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import itp100.DTO.CiklusDTO;
import itp100.DTO.PredmetDTO;

public class PredmetTableModel extends AbstractTableModel {
	private List<PredmetDTO> predmeti;

	public PredmetTableModel(List<PredmetDTO> predmeti) {
		this.predmeti = predmeti;
	}

	@Override
	public int getRowCount() {
		return predmeti.size();
	}

	@Override
	public int getColumnCount() {
		return 4;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		PredmetDTO predmet = predmeti.get(rowIndex);
		Object value = null;
		
		 switch (columnIndex) {
         case 0:
             value = predmet.getId();
             break;
         case 1:
             value = predmet.getNaziv();
             break;
         case 2:
             value = predmet.getObavezan();
             break;
         case 3:
             value = predmet.getEcts();
             break;
		 }
		return value;
	}
		 @Override
		    public String getColumnName(int column) {
		        String name = "??";
		        switch (column) {
		            case 0:
		                name = "ID";
		                break;
		            case 1:
		                name = "Naziv";
		                break;
		            case 2:
		                name = "Obavezan";
		                break;
		            case 3:
		                name = "Ects";
		                break;
		        }
		        return name;
		    }
}
