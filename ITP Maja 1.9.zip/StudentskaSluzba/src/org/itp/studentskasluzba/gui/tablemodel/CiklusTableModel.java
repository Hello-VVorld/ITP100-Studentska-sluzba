package org.itp.studentskasluzba.gui.tablemodel;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import itp100.DTO.CiklusDTO;



public class CiklusTableModel extends AbstractTableModel {
	private List<CiklusDTO> ciklusi;

	public CiklusTableModel(List<CiklusDTO> ciklusi) {
		this.ciklusi=ciklusi;
		
		
	}

	@Override
	public int getRowCount() {
		
		return ciklusi.size();
	}
// koliko kolona ima
	@Override
	public int getColumnCount() {
		return 2; //imamo dvije kolone u tabeli ciklus: id i naziv
	}
//prikaz podataka
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		CiklusDTO ciklus = ciklusi.get(rowIndex);
		Object value = null;
		
		 switch (columnIndex) {
         case 0:
             value = ciklus.getCiklusId();
             break;
         case 1:
             value = ciklus.getNaziv();
             break;
       
     }
     return value;
		
	}
	// za zaglavlje tabele
	 @Override
	    public String getColumnName(int column) {
	        String name = "??";
	        switch (column) {
	            case 0:
	                name = "ID";
	                break;
	            case 1:
	                name = "Naziv";
	                break;
	            
	        }
	        return name;
	    }

}
