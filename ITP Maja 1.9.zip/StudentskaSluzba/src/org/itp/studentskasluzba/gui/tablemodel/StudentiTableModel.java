package org.itp.studentskasluzba.gui.tablemodel;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import itp100.DTO.CiklusDTO;
import itp100.DTO.StudentiDTO;

public class StudentiTableModel extends AbstractTableModel {
	private List<StudentiDTO> studenti;

	public StudentiTableModel(List<StudentiDTO> studenti) {
		this.studenti = studenti;
		
	}

	@Override
	public int getRowCount() {
		return studenti.size();
	}

	@Override
	public int getColumnCount() {
		return 5;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		StudentiDTO student = studenti.get(rowIndex);
		Object value = null;
		
		 switch (columnIndex) {
         case 0:
             value = student.getId();
             break;
         case 1:
             value = student.getImeStudenta();
             break;
         case 2:
        	 value = student.getPrezimeStudenta();
         case 3:
        	 value = student.getBrojIndeksa();
         case 4:
        	 value = student.getGodinaStudija();   
		 }
        	 
		return value;
	}
		 @Override
		    public String getColumnName(int column) {
		        String name = "??";
		        switch (column) {
		            case 0:
		                name = "ID";
		                break;
		            case 1:
		                name = "ImeStudenta";
		                break;
		            case 2:
		                name = "PrezimeStudenta";
		                break;
		            case 3:
		                name = "BrojIndeksa";
		                break;
		            case 4:
		                name = "GodinaStudija";
		                break;
		        }
		        return name;
		    }
}
