package org.itp.studentskasluzba.prikaz.svih.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.itp.studentskasluzba.gui.tablemodel.OglasTableModel;
import org.itp.studentskasluzba.gui.tablemodel.PredmetTableModel;

import itp100.DAO.OglasDAO;
import itp100.DAO.PredmetDAO;
import itp100.DTO.OglasDTO;
import itp100.DTO.PredmetDTO;

import javax.swing.JScrollPane;
import javax.swing.JTable;

public class OglasPrikazSvihGUI extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OglasPrikazSvihGUI frame = new OglasPrikazSvihGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public OglasPrikazSvihGUI() {
		setTitle("Prikaz svih oglasa ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Vector<OglasDTO> oglasi = OglasDAO.getAll();
		List<OglasDTO> oglasKaoLista= new ArrayList<>(oglasi);
		
		//kreiranje tableModela
		OglasTableModel otm = new OglasTableModel(oglasKaoLista);
		table = new JTable(otm);
		table.setBounds(10, 11, 362, 221);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 5, 409, 252);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);
		
		
	}

}
