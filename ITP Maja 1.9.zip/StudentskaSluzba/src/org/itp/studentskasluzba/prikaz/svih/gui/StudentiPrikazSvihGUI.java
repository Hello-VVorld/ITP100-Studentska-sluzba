package org.itp.studentskasluzba.prikaz.svih.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.itp.studentskasluzba.gui.tablemodel.PredmetTableModel;
import org.itp.studentskasluzba.gui.tablemodel.StudentiTableModel;

import itp100.DAO.PredmetDAO;
import itp100.DAO.StudentiDAO;
import itp100.DTO.PredmetDTO;
import itp100.DTO.StudentiDTO;

import javax.swing.JScrollPane;
import javax.swing.JTable;

public class StudentiPrikazSvihGUI extends JFrame {

	private JPanel contentPane;
	private JScrollPane scrollPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentiPrikazSvihGUI frame = new StudentiPrikazSvihGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudentiPrikazSvihGUI() {
		setTitle("Prikaz svih studenata iz baze");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 342);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Vector<StudentiDTO> studenti = StudentiDAO.getAll();
		List<StudentiDTO> studentiKaoLista= new ArrayList<>(studenti);
		//kreiranje tableModela
		StudentiTableModel stm = new StudentiTableModel(studentiKaoLista);
		
		table = new JTable(stm);
		table.setBounds(23, 25, 344, 242);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 369, 256);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);
		
	
	
	}
}
