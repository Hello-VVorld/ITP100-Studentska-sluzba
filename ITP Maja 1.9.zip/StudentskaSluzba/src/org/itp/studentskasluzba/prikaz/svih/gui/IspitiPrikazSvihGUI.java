package org.itp.studentskasluzba.prikaz.svih.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.itp.studentskasluzba.gui.tablemodel.IspitiTableModel;
import org.itp.studentskasluzba.gui.tablemodel.StudijskiProgramTableModel;

import itp100.DAO.IspitiDAO;
import itp100.DAO.StudijskiProgramDAO;
import itp100.DTO.IspitiDTO;
import itp100.DTO.StudijskiProgramDTO;

import javax.swing.JTable;
import javax.swing.JScrollPane;

public class IspitiPrikazSvihGUI extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IspitiPrikazSvihGUI frame = new IspitiPrikazSvihGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IspitiPrikazSvihGUI() {
		setTitle("Prikaz svih ispita");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Vector<IspitiDTO> ispiti =IspitiDAO.getAll();
		List<IspitiDTO> ispitiKaoLista= new ArrayList<>(ispiti);
		
		//kreiranje tableModela
		IspitiTableModel itm = new IspitiTableModel(ispitiKaoLista);
		
		
		table = new JTable(itm);
		table.setBounds(10, 11, 424, 206);
		contentPane.add(table);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(422, 25, 2, 2);
		contentPane.add(scrollPane);
	}
}
