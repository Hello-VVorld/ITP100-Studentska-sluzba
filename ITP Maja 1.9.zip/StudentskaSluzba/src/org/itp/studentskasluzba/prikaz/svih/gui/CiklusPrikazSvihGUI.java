package org.itp.studentskasluzba.prikaz.svih.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import org.itp.studentskasluzba.gui.tablemodel.CiklusTableModel;

import itp100.DAO.CiklusDAO;
import itp100.DTO.CiklusDTO;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class CiklusPrikazSvihGUI extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CiklusPrikazSvihGUI frame = new CiklusPrikazSvihGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CiklusPrikazSvihGUI() {
		setTitle("Prikaz svih ciklusa iz baze");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//kreiramo listu CiklusDTO objekata
		Vector<CiklusDTO> ciklusi = CiklusDAO.getAll();
		List<CiklusDTO> ciklusiKaoLista= new ArrayList<>(ciklusi);
		
		//kreiranje tableModela
		CiklusTableModel ctm = new CiklusTableModel(ciklusiKaoLista);
		
		// proslijedimo table model tabeli kroz kontruktor JTable
		
		table = new JTable(ctm);
		table.setBounds(10, 11, 398, 240);
		
		//dodati scroller da se prikazuje zaglavlje
		// contentPane.add(table);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 23, 414, 213);
		scrollPane.setRowHeaderView(table);
		contentPane.add(scrollPane);
		
	}
}
