package org.itp.studentskasluzba.prikaz.svih.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.itp.studentskasluzba.gui.tablemodel.NastavnikTableModel;
import org.itp.studentskasluzba.gui.tablemodel.PredmetTableModel;

import itp100.DAO.NastavnikDAO;
import itp100.DAO.PredmetDAO;
import itp100.DTO.NastavnikDTO;
import itp100.DTO.PredmetDTO;

import javax.swing.JScrollPane;
import javax.swing.JTable;

public class NastavnikPrikazSvihGUI extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NastavnikPrikazSvihGUI frame = new NastavnikPrikazSvihGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NastavnikPrikazSvihGUI() {
		setTitle("Prikaz svih nastavnika");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Vector<NastavnikDTO> nastavnici = NastavnikDAO.getAll();
		List<NastavnikDTO> nastavnikKaoLista= new ArrayList<>(nastavnici);
		
		//kreiranje tableModela
		NastavnikTableModel ntm = new NastavnikTableModel(nastavnikKaoLista);
		table = new JTable(ntm);
		table.setBounds(10, 11, 362, 221);
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 11, 380, 240);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);
		
		
	}

}
