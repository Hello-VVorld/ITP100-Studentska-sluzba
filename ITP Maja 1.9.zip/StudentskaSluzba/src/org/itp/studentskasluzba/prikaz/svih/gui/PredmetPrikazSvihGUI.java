package org.itp.studentskasluzba.prikaz.svih.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.itp.studentskasluzba.gui.tablemodel.CiklusTableModel;
import org.itp.studentskasluzba.gui.tablemodel.PredmetTableModel;

import itp100.DAO.CiklusDAO;
import itp100.DAO.PredmetDAO;
import itp100.DTO.CiklusDTO;
import itp100.DTO.PredmetDTO;

import javax.swing.JScrollPane;
import javax.swing.JTable;

public class PredmetPrikazSvihGUI extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PredmetPrikazSvihGUI frame = new PredmetPrikazSvihGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PredmetPrikazSvihGUI() {
		setTitle("Prikaz svih predmeta iz baze");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Vector<PredmetDTO> predmeti = PredmetDAO.getAll();
		List<PredmetDTO> predmetiKaoLista= new ArrayList<>(predmeti);
		
		//kreiranje tableModela
		PredmetTableModel ptm = new PredmetTableModel(predmetiKaoLista);
		table = new JTable(ptm);
		table.setBounds(10, 11, 362, 221);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 0, 364, 232);
		scrollPane.setViewportView(table);
		contentPane.add(scrollPane);
		
		
	
	}
}
