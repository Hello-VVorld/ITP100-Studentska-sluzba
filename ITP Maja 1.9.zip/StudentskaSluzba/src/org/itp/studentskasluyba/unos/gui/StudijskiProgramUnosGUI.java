package org.itp.studentskasluyba.unos.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.itp.studentskasluzba.prikaz.svih.gui.CiklusPrikazSvihGUI;
import org.itp.studentskasluzba.prikaz.svih.gui.StudijskiProgramPrikazSvihGUI;

import itp100.DAO.CiklusDAO;
import itp100.DAO.NastavnikDAO;
import itp100.DAO.StudijskiProgramDAO;
import itp100.DTO.CiklusDTO;
import itp100.DTO.NastavnikDTO;
import itp100.DTO.StudijskiProgramDTO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;

public class StudijskiProgramUnosGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudijskiProgramUnosGUI frame = new StudijskiProgramUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudijskiProgramUnosGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Naziv:");
		lblNewLabel.setBounds(10, 11, 112, 14);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(20, 36, 330, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblCiklus = new JLabel("Ciklus:");
		lblCiklus.setBounds(10, 67, 103, 14);
		contentPane.add(lblCiklus);
		
		JButton btnNewButton = new JButton("Prikaz svih st.programa");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				StudijskiProgramPrikazSvihGUI prikazSvih = new StudijskiProgramPrikazSvihGUI();
				prikazSvih.setVisible(true);
				
				
			}
		});
		btnNewButton.setBounds(10, 228, 181, 23);
		contentPane.add(btnNewButton);
		Vector<StudijskiProgramDTO> sviCiklusi= StudijskiProgramDAO.getAll();
		JComboBox comboBox = new JComboBox(sviCiklusi);
		comboBox.setBounds(20, 92, 202, 22);
		contentPane.add(comboBox);
		JButton btnNewButton_1 = new JButton("Unos:");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nazivStudijskogPrograma = textField.getText();
				int ciklusStudijskogProgramaId = Integer.parseInt(comboBox.getSelectedItem().toString().split("-")[0]);
				
				
				StudijskiProgramDTO sp = new StudijskiProgramDTO();
				sp.setNaziv(nazivStudijskogPrograma);
				sp.setCiklus(ciklusStudijskogProgramaId);
				boolean uspjesno = StudijskiProgramDAO.dodajStudijskiProgram(sp);
				String bool = uspjesno ? "Uspjesno ste dodali studijski program." : "Dogodila se greska pri dodavanju studijskog programa.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		btnNewButton_1.setBounds(335, 228, 89, 23);
		contentPane.add(btnNewButton_1);
		

		

	}
}
