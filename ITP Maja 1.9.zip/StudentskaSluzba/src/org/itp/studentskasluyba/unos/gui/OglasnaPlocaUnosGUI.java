package org.itp.studentskasluyba.unos.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.itp.studentskasluzba.prikaz.svih.gui.CiklusPrikazSvihGUI;
import org.itp.studentskasluzba.prikaz.svih.gui.OglasnaPlocaPrikazSvihGUI;

import itp100.DAO.CiklusDAO;
import itp100.DAO.OglasnaPlocaDAO;
import itp100.DTO.CiklusDTO;
import itp100.DTO.OglasnaPlocaDTO;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

public class OglasnaPlocaUnosGUI extends JFrame {

	private JPanel contentPane;
	private JTextField tfOglasnaPloca;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OglasnaPlocaUnosGUI frame = new OglasnaPlocaUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public OglasnaPlocaUnosGUI() {
		setTitle("Oglasna ploca unos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblOglasnaPloca = new JLabel("Oglasna ploca:");
		lblOglasnaPloca.setBounds(24, 24, 102, 14);
		contentPane.add(lblOglasnaPloca);
		
		tfOglasnaPloca = new JTextField();
		tfOglasnaPloca.setBounds(24, 50, 355, 20);
		contentPane.add(tfOglasnaPloca);
		tfOglasnaPloca.setColumns(10);
		
		JButton btnUnos = new JButton("UNOS");
		btnUnos.setBounds(262, 212, 89, 23);
		contentPane.add(btnUnos);
		btnUnos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String oglasnaPloca = tfOglasnaPloca.getText();
				OglasnaPlocaDTO og = new OglasnaPlocaDTO();
				og.setOglasnaPloca(oglasnaPloca);
				boolean uspjesno = OglasnaPlocaDAO.dodajOglasnuPlocu(og);
				String bool = uspjesno ? "Uspjesno ste dodali oglasnu plocu." : "Dogodila se greska pri dodavanju oglasne ploce.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		btnUnos.setBounds(341, 226, 91, 23);
		contentPane.add(btnUnos);
		
		JButton btnPrikazOglasnePloce = new JButton("Prikaz oglasne ploce");
		btnPrikazOglasnePloce.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OglasnaPlocaPrikazSvihGUI prikazSvih = new OglasnaPlocaPrikazSvihGUI();
				prikazSvih.setVisible(true);
				
			}
		});
		btnPrikazOglasnePloce.setBounds(48, 226, 169, 23);
		contentPane.add(btnPrikazOglasnePloce);
	}
}
	
