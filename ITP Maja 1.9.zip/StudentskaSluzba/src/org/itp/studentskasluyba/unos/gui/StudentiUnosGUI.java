package org.itp.studentskasluyba.unos.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import org.itp.studentskasluzba.prikaz.svih.gui.StudentiPrikazSvihGUI;


import itp100.DAO.StudentiDAO;
import itp100.DTO.StudentiDTO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;

public class StudentiUnosGUI extends JFrame {

	private JPanel contentPane;
	private JTextField tfImeStudenta;
	private JTextField tfPrezimeStudenta;
	private JTextField tfBrojIndeksa;
	private JTextField tfGodinaStudija;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentiUnosGUI frame = new StudentiUnosGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudentiUnosGUI() {
		setTitle("Unos studenata");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblImeStudenta = new JLabel("Ime studenta:");
		lblImeStudenta.setBounds(10, 11, 78, 14);
		contentPane.add(lblImeStudenta);
		
		JLabel lblPrezimeStudenta = new JLabel("Prezime studenta:");
		lblPrezimeStudenta.setBounds(10, 53, 78, 14);
		contentPane.add(lblPrezimeStudenta);
		
		tfImeStudenta = new JTextField();
		tfImeStudenta.setBounds(98, 8, 294, 20);
		contentPane.add(tfImeStudenta);
		tfImeStudenta.setColumns(10);
		
		tfPrezimeStudenta = new JTextField();
		tfPrezimeStudenta.setBounds(98, 50, 294, 20);
		contentPane.add(tfPrezimeStudenta);
		tfPrezimeStudenta.setColumns(10);
		
		JLabel lblBrojIndeksa = new JLabel("Broj indeksa:");
		lblBrojIndeksa.setBounds(10, 95, 78, 14);
		contentPane.add(lblBrojIndeksa);
		
		tfBrojIndeksa = new JTextField();
		tfBrojIndeksa.setBounds(98, 92, 294, 20);
		contentPane.add(tfBrojIndeksa);
		tfBrojIndeksa.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Godina studija");
		lblNewLabel.setBounds(10, 136, 48, 14);
		contentPane.add(lblNewLabel);
		
		tfGodinaStudija = new JTextField();
		tfGodinaStudija.setBounds(98, 133, 294, 20);
		contentPane.add(tfGodinaStudija);
		tfGodinaStudija.setColumns(10);
		
		
		
		JButton btnUnos = new JButton("UNOS");
		btnUnos.setBounds(265, 212, 89, 23);
		btnUnos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String imeStudenta = tfImeStudenta.getText();
				String prezimeStudenta = tfPrezimeStudenta.getText();
				int brojIndeksa = Integer.parseInt(tfBrojIndeksa .getText());
				int godinaStudija = Integer.parseInt(tfGodinaStudija .getText());
				
				StudentiDTO s = new StudentiDTO();
				
				s.setImeStudenta(imeStudenta);
				s.setPrezimeStudenta(prezimeStudenta);
				s.setBrojIndeksa(brojIndeksa);
				s.setGodinaStudija(godinaStudija);
				
				boolean uspjesno = StudentiDAO.dodajStudente(s);
				String bool = uspjesno ? "Uspjesno ste dodali studenta." : "Dogodila se greska pri dodavanju studenta.";
				JOptionPane.showMessageDialog(null, bool);
			}
		});
		btnUnos.setBounds(341, 226, 91, 23);
		contentPane.add(btnUnos);
		
		JButton btnPrikazSvihStudenata = new JButton("Prikaz svih studenata");
		btnPrikazSvihStudenata.setBounds(38, 212, 147, 23);
		contentPane.add(btnPrikazSvihStudenata);
		
		btnPrikazSvihStudenata.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentiPrikazSvihGUI prikazSvih = new StudentiPrikazSvihGUI();
				prikazSvih.setVisible(true);
				
			}
		});
	}
}
