package org.itp.studentskasluyba.unos.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import itp100.DAO.IspitiDAO;
import itp100.DAO.NastavnikDAO;
import itp100.DAO.PredmetDAO;
import itp100.DAO.StudentiDAO;
import itp100.DAO.StudijskiProgramDAO;
import itp100.DTO.IspitiDTO;
import itp100.DTO.NastavnikDTO;
import itp100.DTO.PredmetDTO;
import itp100.DTO.StudentiDTO;
import itp100.DTO.StudijskiProgramDTO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;

public class UnosIspitaGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UnosIspitaGUI frame = new UnosIspitaGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UnosIspitaGUI() {
		setTitle("UNOS ISPITA");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblStudent = new JLabel("Student");
		lblStudent.setBounds(5, 5, 70, 14);
		contentPane.add(lblStudent);
		
		//popuniti combo svim studentima
		Vector<StudentiDTO> sviStudenti= StudentiDAO.getAll();
		
		
		
		JComboBox cbStudent = new JComboBox(sviStudenti);
		cbStudent.setBounds(127, 1, 228, 22);
		contentPane.add(cbStudent);
		
		JLabel lblPredmet = new JLabel("Predmet:");
		lblPredmet.setBounds(5, 41, 53, 14);
		contentPane.add(lblPredmet);
		
		Vector<PredmetDTO> sviPredmeti= PredmetDAO.getAll();
		JComboBox cbPredmet = new JComboBox(sviPredmeti);
		cbPredmet.setBounds(127, 37, 228, 22);
		contentPane.add(cbPredmet);
		
		JLabel lblStudijskiProgram = new JLabel("Studijski program:");
		lblStudijskiProgram.setBounds(5, 78, 100, 14);
		contentPane.add(lblStudijskiProgram);
		
		Vector<StudijskiProgramDTO> sviSP= StudijskiProgramDAO.getAll();
		JComboBox cbStudijskiProgram = new JComboBox(sviSP);
		cbStudijskiProgram.setBounds(127, 74, 228, 22);
		contentPane.add(cbStudijskiProgram);
		
		JLabel lblNastavnik = new JLabel("Nastavnik:");
		lblNastavnik.setBounds(5, 116, 100, 14);
		contentPane.add(lblNastavnik);
		
		Vector<NastavnikDTO> sviNastavnici= NastavnikDAO.getAll();
		JComboBox cbNastavnik = new JComboBox(sviNastavnici);
		cbNastavnik.setBounds(127, 107, 228, 22);
		contentPane.add(cbNastavnik);
		
		JLabel lblOcjena = new JLabel("Ocjena:");
		lblOcjena.setBounds(5, 141, 85, 14);
		contentPane.add(lblOcjena);
		
		textField = new JTextField();
		textField.setBounds(127, 140, 228, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblBrojBodova = new JLabel("BrojBodova:");
		lblBrojBodova.setBounds(5, 177, 70, 14);
		contentPane.add(lblBrojBodova);
		
		textField_1 = new JTextField();
		textField_1.setBounds(127, 171, 228, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblDatum = new JLabel("Datum:");
		lblDatum.setBounds(5, 203, 53, 14);
		contentPane.add(lblDatum);
		
		textField_2 = new JTextField();
		textField_2.setBounds(127, 202, 228, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton = new JButton("Sacuvaj");
		btnNewButton.setBounds(130, 233, 142, 23);
		contentPane.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			
		
			public void actionPerformed(ActionEvent e) {
				int IdStudent = Integer.parseInt(cbStudent.getSelectedItem().toString().split("-")[0]);
				int IdPredmet = Integer.parseInt(cbPredmet.getSelectedItem().toString().split("-")[0]);
				int IdStudijskiProgram = Integer.parseInt(cbStudijskiProgram.getSelectedItem().toString().split("-")[0]);
				int IdNastavnik = Integer.parseInt(cbNastavnik.getSelectedItem().toString().split("-")[0]);
				int ocjena = Integer.parseInt(textField.getText());
				int brojBodova = Integer.parseInt(textField_1.getText());
				String datum = textField_2.getText();
						
						IspitiDTO ispitZaUnos = new IspitiDTO(0, datum, ocjena, brojBodova, IdNastavnik, IdPredmet, IdStudent,
								IdStudijskiProgram);
						
						boolean uspjesnoDodavanje = IspitiDAO.dodajIspit(ispitZaUnos);
						if (uspjesnoDodavanje) {
							JOptionPane.showMessageDialog(null, "Unos ispita uspjesan!");
							
						}else
							JOptionPane.showMessageDialog(null, "Unos nije uspio!");
						
						
			}
		});
		

	}
}
